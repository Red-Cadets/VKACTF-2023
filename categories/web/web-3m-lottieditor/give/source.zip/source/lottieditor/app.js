const express = require("express");

const PORT = 3000;
const HOST = '0.0.0.0';

const app = express();

const bodyparser = require('body-parser');
app.use(bodyparser.urlencoded({ extended: false }))
app.use(bodyparser.json()) 
app.set("view engine", "ejs");

const routes = require("./routes/routes")

const path = require('path')



app.use('/static', express.static(path.join(__dirname, 'static')))
app.use('/', routes);

app.listen(PORT, HOST, () => {
  console.log(`Running on http://${HOST}:${PORT}`);
});