const path = require('path')

const utils = require("../utils/Lottie")

exports.ChangeMetadata = (req, res) => {
    let lottie_json, newData;
    filename = req.query.filename
    if (filename === undefined){
      res.status(404).send({message: "Файл не найден"});
      return
    }
    let data = utils.ReadFile(filename)
    if(data == null){
      res.status(404).send({message: "Файл не найден"});
      return
    }
    
    try {
      lottie_json = JSON.parse(data)
      newData = req.body
    } catch {
      res.status(404).send({message: "Body JSON Error"});
      return
    }
    

  lottie_json = utils.ChangeLottie(lottie_json, newData)
  if(lottie_json == null){
    res.status(404).send({message: "Ошибка в изменении json"});
    return
  }   

  filename = utils.SaveFile(lottie_json)
  res.download(path.join(__dirname, "..", "utils", "save_data", filename))
}