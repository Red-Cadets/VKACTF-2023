const schema = {
    "$id": "https://lottiefiles.github.io/lottie-docs/schema/lottie.schema.json",
    "type": "object",
    "allOf": [
        {
            "$ref": "#/$defs/animation/animation"
        }
    ],
    "$defs": {
        "animated-properties": {
            "shape-property": {
                "type": "object",
                "title": "Shape Property",
                "description": "An animatable property that holds a Bezier",
                "allOf": [
                    {
                        "properties": {
                            "ix": {
                                "title": "Property Index",
                                "type": "integer"
                            },
                            "a": {
                                "title": "Animated",
                                "description": "Whether the property is animated",
                                "$ref": "#/$defs/helpers/int-boolean",
                                "default": 0
                            },
                            "x": {
                                "title": "Expression",
                                "type": "string"
                            }
                        }
                    },
                    {
                        "if": {
                            "properties": {
                                "a": {
                                    "const": 1
                                }
                            }
                        },
                        "then": {
                            "properties": {
                                "k": {
                                    "type": "array",
                                    "title": "Animated Value",
                                    "description": "Array of keyframes",
                                    "items": {
                                        "$ref": "#/$defs/animated-properties/shape-keyframe"
                                    }
                                }
                            }
                        },
                        "else": {
                            "properties": {
                                "k": {
                                    "$ref": "#/$defs/helpers/bezier",
                                    "title": "Static Value"
                                }
                            }
                        }
                    }
                ],
                "required": [
                    "k"
                ]
            },
            "keyframe-base": {
                "type": "object",
                "title": "Base Keyframe",
                "description": "A Keyframes specifies the value at a specific time and the interpolation function to reach the next keyframe.",
                "allOf": [
                    {
                        "properties": {
                            "t": {
                                "title": "Time",
                                "type": "number",
                                "default": 0
                            },
                            "h": {
                                "title": "Hold",
                                "$ref": "#/$defs/helpers/int-boolean",
                                "default": 0
                            }
                        }
                    },
                    {
                        "if": {
                            "oneOf": [
                                {
                                    "properties": {
                                        "h": {
                                            "const": 0
                                        }
                                    }
                                },
                                {
                                    "not": {
                                        "required": [
                                            "h"
                                        ]
                                    }
                                }
                            ]
                        },
                        "then": {
                            "properties": {
                                "i": {
                                    "title": "In Tangent",
                                    "description": "Easing tangent going into the next keyframe",
                                    "$ref": "#/$defs/animated-properties/keyframe-bezier-handle"
                                },
                                "o": {
                                    "title": "Out Tangent",
                                    "description": "Easing tangent leaving the current keyframe",
                                    "$ref": "#/$defs/animated-properties/keyframe-bezier-handle"
                                }
                            }
                        }
                    }
                ],
                "required": [
                    "t",
                    "s"
                ]
            },
            "multi-dimensional": {
                "type": "object",
                "title": "Multi Dimensional",
                "description": "An animatable property that holds an array of numbers",
                "allOf": [
                    {
                        "$ref": "#/$defs/animated-properties/animated-property"
                    },
                    {
                        "if": {
                            "properties": {
                                "a": {
                                    "const": 0
                                }
                            }
                        },
                        "then": {
                            "properties": {
                                "k": {
                                    "title": "Static value",
                                    "type": "array",
                                    "items": {
                                        "type": "number"
                                    }
                                }
                            }
                        },
                        "properties": {
                            "l": {
                                "title": "Length",
                                "description": "Number of components in the value arrays.\nIf present values will be truncated or expanded to match this length when accessed from expressions.",
                                "type": "integer"
                            }
                        }
                    }
                ]
            },
            "keyframe": {
                "type": "object",
                "title": "Keyframe",
                "description": "A Keyframes specifies the value at a specific time and the interpolation function to reach the next keyframe.",
                "allOf": [
                    {
                        "$ref": "#/$defs/animated-properties/keyframe-base"
                    },
                    {
                        "properties": {
                            "s": {
                                "title": "Value",
                                "description": "Value at this keyframe. Note the if the property is a scalar, keyframe values are still represented as arrays",
                                "type": "array",
                                "items": {
                                    "type": "number"
                                }
                            },
                            "e": {
                                "title": "End value",
                                "description": "Value at the end of the keyframe, note that this is deprecated and you should use `s` from the next keyframe to get this value",
                                "deprecated": true,
                                "type": "array",
                                "items": {
                                    "type": "number"
                                }
                            }
                        }
                    },
                    {
                        "if": {
                            "oneOf": [
                                {
                                    "properties": {
                                        "h": {
                                            "const": 0
                                        }
                                    }
                                },
                                {
                                    "not": {
                                        "required": [
                                            "h"
                                        ]
                                    }
                                }
                            ]
                        },
                        "then": {
                            "properties": {
                                "i": {
                                    "title": "In Tangent",
                                    "description": "Easing tangent going into the next keyframe",
                                    "$ref": "#/$defs/animated-properties/keyframe-bezier-handle"
                                },
                                "o": {
                                    "title": "Out Tangent",
                                    "description": "Easing tangent leaving the current keyframe",
                                    "$ref": "#/$defs/animated-properties/keyframe-bezier-handle"
                                }
                            }
                        }
                    }
                ],
                "required": [
                    "t",
                    "s"
                ]
            },
            "gradient-colors": {
                "type": "object",
                "title": "Gradient Colors",
                "description": "Represents colors and offsets in a gradient\n\nColors are represented as a flat list interleaving offsets and color components in weird ways\nThere are two possible layouts:\n\nWithout alpha, the colors are a sequence of offset, r, g, b\n\nWith alpha, same as above but at the end of the list there is a sequence of offset, alpha",
                "properties": {
                    "k": {
                        "title": "Colors",
                        "$ref": "#/$defs/animated-properties/multi-dimensional"
                    },
                    "p": {
                        "title": "Count",
                        "description": "Number of colors in `k`",
                        "type": "integer",
                        "default": 0
                    }
                },
                "required": [
                    "p",
                    "k"
                ]
            },
            "animated-property": {
                "type": "object",
                "title": "Animated Property",
                "description": "An animatable property that holds an array of numbers",
                "allOf": [
                    {
                        "properties": {
                            "ix": {
                                "title": "Property Index",
                                "type": "integer"
                            },
                            "a": {
                                "title": "Animated",
                                "description": "Whether the property is animated",
                                "$ref": "#/$defs/helpers/int-boolean",
                                "default": 0
                            },
                            "x": {
                                "title": "Expression",
                                "type": "string"
                            },
                            "sid": {
                                "title": "Slot ID",
                                "description": "One of the ID in the file's slots",
                                "type": "string"
                            }
                        }
                    },
                    {
                        "if": {
                            "properties": {
                                "a": {
                                    "const": 1
                                }
                            }
                        },
                        "then": {
                            "properties": {
                                "k": {
                                    "type": "array",
                                    "title": "Animated Value",
                                    "description": "Array of keyframes",
                                    "items": {
                                        "$ref": "#/$defs/animated-properties/keyframe"
                                    }
                                }
                            }
                        }
                    }
                ],
                "required": [
                    "k"
                ]
            },
            "split-vector": {
                "type": "object",
                "title": "Split Vector",
                "description": "An animatable property that is split into individually anaimated components",
                "properties": {
                    "s": {
                        "title": "Split",
                        "type": "boolean",
                        "const": true
                    },
                    "x": {
                        "title": "X",
                        "$ref": "#/$defs/animated-properties/value"
                    },
                    "y": {
                        "title": "Y",
                        "$ref": "#/$defs/animated-properties/value"
                    },
                    "z": {
                        "title": "Z",
                        "$ref": "#/$defs/animated-properties/value"
                    }
                },
                "required": [
                    "s",
                    "x",
                    "y"
                ]
            },
            "shape-keyframe": {
                "type": "object",
                "title": "Shape Keyframe",
                "description": "Keyframe holding Bezier objects",
                "allOf": [
                    {
                        "$ref": "#/$defs/animated-properties/keyframe-base"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "s": {
                                "title": "Start",
                                "type": "array",
                                "items": {
                                    "$ref": "#/$defs/helpers/bezier"
                                }
                            }
                        }
                    }
                ]
            },
            "value": {
                "type": "object",
                "title": "Value",
                "description": "An animatable property that holds a float",
                "allOf": [
                    {
                        "$ref": "#/$defs/animated-properties/animated-property"
                    },
                    {
                        "if": {
                            "properties": {
                                "a": {
                                    "const": 0
                                }
                            }
                        },
                        "then": {
                            "properties": {
                                "k": {
                                    "title": "Static value",
                                    "type": "number"
                                }
                            }
                        }
                    }
                ]
            },
            "position": {
                "type": "object",
                "title": "Position Property",
                "description": "An animatable property to represent a position in space",
                "allOf": [
                    {
                        "properties": {
                            "ix": {
                                "title": "Property Index",
                                "type": "integer"
                            },
                            "a": {
                                "title": "Animated",
                                "description": "Whether the property is animated",
                                "$ref": "#/$defs/helpers/int-boolean",
                                "default": 0
                            },
                            "x": {
                                "title": "Expression",
                                "type": "string"
                            },
                            "l": {
                                "title": "Length",
                                "description": "Number of components in the value arrays.\nIf present values will be truncated or expanded to match this length when accessed from expressions.",
                                "type": "integer"
                            }
                        }
                    },
                    {
                        "if": {
                            "properties": {
                                "a": {
                                    "const": 1
                                }
                            }
                        },
                        "then": {
                            "properties": {
                                "k": {
                                    "type": "array",
                                    "title": "Animated Value",
                                    "description": "Array of keyframes",
                                    "items": {
                                        "$ref": "#/$defs/animated-properties/position-keyframe"
                                    }
                                }
                            }
                        },
                        "else": {
                            "properties": {
                                "k": {
                                    "title": "Static Value",
                                    "type": "array",
                                    "items": {
                                        "type": "number"
                                    }
                                }
                            }
                        }
                    }
                ],
                "required": [
                    "k"
                ]
            },
            "position-keyframe": {
                "type": "object",
                "title": "Position Keyframe",
                "allOf": [
                    {
                        "$ref": "#/$defs/animated-properties/keyframe"
                    },
                    {
                        "properties": {
                            "ti": {
                                "title": "Value In Tangent",
                                "description": "Tangent for values (eg: moving position around a curved path)",
                                "type": "array",
                                "items": {
                                    "type": "number"
                                }
                            },
                            "to": {
                                "title": "Value Out Tangent",
                                "description": "Tangent for values (eg: moving position around a curved path)",
                                "type": "array",
                                "items": {
                                    "type": "number"
                                }
                            }
                        }
                    }
                ]
            },
            "color-value": {
                "type": "object",
                "title": "Color Value",
                "description": "An animatable property that holds a Color",
                "allOf": [
                    {
                        "$ref": "#/$defs/animated-properties/animated-property"
                    },
                    {
                        "if": {
                            "properties": {
                                "a": {
                                    "const": 0
                                }
                            }
                        },
                        "then": {
                            "properties": {
                                "k": {
                                    "title": "Static value",
                                    "$ref": "#/$defs/helpers/color"
                                }
                            }
                        }
                    }
                ]
            },
            "keyframe-bezier-handle": {
                "type": "object",
                "title": "Keyframe Bezier Handle",
                "description": "Bezier handle for keyframe interpolation",
                "properties": {
                    "x": {
                        "title": "X",
                        "description": "Time component:\n0 means start time of the keyframe,\n1 means time of the next keyframe.",
                        "oneOf": [
                            {
                                "type": "array",
                                "items": {
                                    "type": "number",
                                    "default": 0,
                                    "minimum": 0,
                                    "maximum": 1
                                },
                                "minItems": 1
                            },
                            {
                                "type": "number",
                                "default": 0,
                                "minimum": 0,
                                "maximum": 1
                            }
                        ]
                    },
                    "y": {
                        "title": "Y",
                        "description": "Value interpolation component:\n0 means start value of the keyframe,\n1 means value at the next keyframe.",
                        "oneOf": [
                            {
                                "type": "array",
                                "items": {
                                    "type": "number",
                                    "default": 0,
                                    "minimum": 0,
                                    "maximum": 1
                                },
                                "minItems": 1
                            },
                            {
                                "type": "number",
                                "default": 0,
                                "minimum": 0,
                                "maximum": 1
                            }
                        ]
                    }
                },
                "required": [
                    "x",
                    "y"
                ]
            }
        },
        "animation": {
            "animation": {
                "type": "object",
                "title": "Animation",
                "description": "Top level object, describing the animation",
                "allOf": [
                    {
                        "$ref": "#/$defs/helpers/visual-object"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "v": {
                                "title": "Version",
                                "type": "string",
                                "default": "5.5.2"
                            },
                            "fr": {
                                "title": "Framerate",
                                "description": "Framerate in frames per second",
                                "type": "number",
                                "default": 60
                            },
                            "ip": {
                                "title": "In Point",
                                "description": "\"In Point\", which frame the animation starts at (usually 0)",
                                "type": "number",
                                "default": 0
                            },
                            "op": {
                                "title": "Out Point",
                                "description": "\"Out Point\", which frame the animation stops/loops at, which makes this the duration in frames when `ip` is 0",
                                "type": "number",
                                "default": 60
                            },
                            "w": {
                                "title": "Width",
                                "description": "Width of the animation",
                                "type": "integer",
                                "default": 512
                            },
                            "h": {
                                "title": "Height",
                                "description": "Height of the animation",
                                "type": "integer",
                                "default": 512
                            },
                            "ddd": {
                                "title": "Threedimensional",
                                "$ref": "#/$defs/helpers/int-boolean",
                                "default": 0,
                                "description": "Whether the animation has 3D layers"
                            },
                            "assets": {
                                "title": "Assets",
                                "type": "array",
                                "description": "List of assets that can be referenced by layers",
                                "items": {
                                    "oneOf": [
                                        {
                                            "$ref": "#/$defs/assets/image"
                                        },
                                        {
                                            "$ref": "#/$defs/assets/precomposition"
                                        },
                                        {
                                            "$ref": "#/$defs/assets/sound"
                                        },
                                        {
                                            "$ref": "#/$defs/assets/data-source"
                                        }
                                    ]
                                }
                            },
                            "comps": {
                                "title": "Extra Compositions",
                                "type": "array",
                                "description": "List of Extra compositions not referenced by anything",
                                "items": {
                                    "$ref": "#/$defs/assets/precomposition"
                                }
                            },
                            "fonts": {
                                "title": "Fonts",
                                "$ref": "#/$defs/text/font-list"
                            },
                            "chars": {
                                "title": "Characters",
                                "description": "Data defining text characters as lottie shapes. If present a player might only render characters defined here and nothing else.",
                                "type": "array",
                                "items": {
                                    "$ref": "#/$defs/text/character-data"
                                }
                            },
                            "meta": {
                                "title": "Metadata",
                                "description": "Document metadata",
                                "$ref": "#/$defs/animation/metadata"
                            },
                            "metadata": {
                                "title": "User Metadata",
                                "$ref": "#/$defs/animation/user-metadata"
                            },
                            "markers": {
                                "title": "Markers",
                                "description": "Markers defining named sections of the composition.",
                                "type": "array",
                                "items": {
                                    "$ref": "#/$defs/helpers/marker"
                                }
                            },
                            "mb": {
                                "title": "Motion Blur",
                                "$ref": "#/$defs/animation/motion-blur"
                            },
                            "slots": {
                                "title": "Slots",
                                "description": "Available property overrides",
                                "type": "object",
                                "patternProperties": {
                                    ".*": {
                                        "anyOf": [
                                            {
                                                "$ref": "#/$defs/animated-properties/multi-dimensional"
                                            },
                                            {
                                                "$ref": "#/$defs/animated-properties/color-value"
                                            },
                                            {
                                                "$ref": "#/$defs/animated-properties/position"
                                            },
                                            {
                                                "$ref": "#/$defs/animated-properties/shape-property"
                                            },
                                            {
                                                "$ref": "#/$defs/animated-properties/value"
                                            }
                                        ]
                                    }
                                }
                            }
                        },
                        "required": [
                            "w",
                            "h",
                            "fr",
                            "layers",
                            "op",
                            "ip"
                        ]
                    },
                    {
                        "$ref": "#/$defs/animation/composition"
                    }
                ]
            },
            "motion-blur": {
                "type": "object",
                "title": "Motion Blur",
                "description": "Motion blur settings",
                "properties": {
                    "sa": {
                        "title": "Shutter Angle",
                        "description": "Angle in degrees",
                        "type": "number"
                    },
                    "sp": {
                        "title": "Shutter Phase",
                        "description": "Angle in degrees",
                        "type": "number"
                    },
                    "spf": {
                        "title": "Samples per Frame",
                        "type": "number"
                    },
                    "asl": {
                        "title": "Adaptive Sample Limit",
                        "type": "number"
                    }
                }
            },
            "composition": {
                "type": "object",
                "title": "Composition",
                "description": "Base class for layer holders",
                "properties": {
                    "layers": {
                        "title": "Layers",
                        "type": "array",
                        "items": {
                            "oneOf": [
                                {
                                    "$ref": "#/$defs/layers/precomposition-layer"
                                },
                                {
                                    "$ref": "#/$defs/layers/solid-color-layer"
                                },
                                {
                                    "$ref": "#/$defs/layers/image-layer"
                                },
                                {
                                    "$ref": "#/$defs/layers/null-layer"
                                },
                                {
                                    "$ref": "#/$defs/layers/shape-layer"
                                },
                                {
                                    "$ref": "#/$defs/layers/text-layer"
                                },
                                {
                                    "$ref": "#/$defs/layers/audio-layer"
                                },
                                {
                                    "$ref": "#/$defs/layers/camera-layer"
                                },
                                {
                                    "$ref": "#/$defs/layers/data-layer"
                                }
                            ]
                        }
                    }
                },
                "required": [
                    "layers"
                ]
            },
            "metadata": {
                "type": "object",
                "title": "Metadata",
                "description": "Document metadata",
                "properties": {
                    "a": {
                        "title": "Author",
                        "type": "string"
                    },
                    "d": {
                        "title": "Description",
                        "type": "string"
                    },
                    "tc": {
                        "title": "Theme Color",
                        "type": "string"
                    },
                    "g": {
                        "title": "Generator",
                        "description": "Software used to generate the file",
                        "type": "string"
                    }
                },
                "anyOf": [
                    {
                        "properties": {
                            "k": {
                                "title": "Keywords",
                                "type": "array",
                                "items": {
                                    "type": "string"
                                }
                            }
                        }
                    },
                    {
                        "properties": {
                            "k": {
                                "title": "Keywords",
                                "type": "string"
                            }
                        }
                    }
                ]
            },
            "user-metadata": {
                "type": "object",
                "title": "User Metadata",
                "description": "User-defined metadata",
                "properties": {
                    "filename": {
                        "title": "Filename",
                        "type": "string"
                    },
                    "customProps": {
                        "title": "Custom Properties",
                        "type": "object"
                    }
                }
            }
        },
        "assets": {
            "sound": {
                "type": "object",
                "title": "Sound",
                "description": "External sound",
                "allOf": [
                    {
                        "$ref": "#/$defs/assets/file-asset"
                    }
                ]
            },
            "precomposition": {
                "type": "object",
                "title": "Precomposition",
                "description": "Asset containing an animation that can be referenced by layers.",
                "allOf": [
                    {
                        "$ref": "#/$defs/assets/asset"
                    },
                    {
                        "$ref": "#/$defs/animation/composition"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "fr": {
                                "title": "Framerate",
                                "description": "Framerate in frames per second",
                                "type": "number"
                            },
                            "xt": {
                                "title": "Extra",
                                "description": "Extra composition",
                                "$ref": "#/$defs/helpers/int-boolean",
                                "default": 0
                            }
                        }
                    }
                ]
            },
            "image": {
                "type": "object",
                "title": "Image",
                "description": "External image",
                "allOf": [
                    {
                        "$ref": "#/$defs/assets/file-asset"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "w": {
                                "title": "Width",
                                "description": "Width of the image",
                                "type": "number",
                                "default": 0
                            },
                            "h": {
                                "title": "Height",
                                "description": "Height of the image",
                                "type": "number",
                                "default": 0
                            },
                            "t": {
                                "title": "Type",
                                "description": "Marks as part of an image sequence if present",
                                "type": "string",
                                "const": "seq"
                            }
                        },
                        "required": [
                            "p"
                        ]
                    }
                ]
            },
            "file-asset": {
                "type": "object",
                "title": "File Asset",
                "description": "Asset referencing a file",
                "allOf": [
                    {
                        "$ref": "#/$defs/assets/asset"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "u": {
                                "title": "Path",
                                "description": "Path to the directory containing a file",
                                "type": "string",
                                "default": ""
                            },
                            "p": {
                                "title": "File name",
                                "description": "Filename or data url",
                                "type": "string",
                                "default": ""
                            },
                            "e": {
                                "title": "Embedded",
                                "description": "Whether the file is embedded",
                                "$ref": "#/$defs/helpers/int-boolean",
                                "default": 0
                            }
                        },
                        "required": [
                            "p"
                        ]
                    }
                ]
            },
            "data-source": {
                "type": "object",
                "title": "Data source",
                "description": "External data source, usually a JSON file",
                "allOf": [
                    {
                        "$ref": "#/$defs/assets/file-asset"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "t": {
                                "title": "Type",
                                "type": "integer",
                                "const": 3
                            }
                        },
                        "required": [
                            "t"
                        ]
                    }
                ]
            },
            "asset": {
                "type": "object",
                "title": "Asset",
                "description": "",
                "allOf": [
                    {
                        "type": "object",
                        "properties": {
                            "id": {
                                "title": "ID",
                                "description": "Unique identifier used by layers when referencing this asset",
                                "type": "string",
                                "default": ""
                            },
                            "nm": {
                                "title": "Name",
                                "description": "Human readable name",
                                "type": "string"
                            }
                        },
                        "required": [
                            "id"
                        ]
                    }
                ]
            }
        },
        "constants": {
            "trim-multiple-shapes": {
                "type": "integer",
                "title": "Trim Multiple Shapes",
                "description": "How to handle multiple shapes in trim path",
                "oneOf": [
                    {
                        "title": "Individually",
                        "const": 1
                    },
                    {
                        "title": "Simultaneously",
                        "const": 2
                    }
                ]
            },
            "merge-mode": {
                "type": "integer",
                "title": "Merge Mode",
                "description": "Boolean operation on shapes",
                "oneOf": [
                    {
                        "title": "Normal",
                        "const": 1
                    },
                    {
                        "title": "Add",
                        "const": 2
                    },
                    {
                        "title": "Subtract",
                        "const": 3
                    },
                    {
                        "title": "Intersect",
                        "const": 4
                    },
                    {
                        "title": "Exclude Intersections",
                        "const": 5
                    }
                ]
            },
            "fill-rule": {
                "type": "integer",
                "title": "Fill Rule",
                "description": "Rule used to handle multiple shapes rendered with the same fill object",
                "oneOf": [
                    {
                        "title": "Non Zero",
                        "description": "Everything is colored (You can think of this as an OR)",
                        "const": 1
                    },
                    {
                        "title": "Even Odd",
                        "description": "Colored based on intersections and path direction, can be used to create \"holes\"",
                        "const": 2
                    }
                ]
            },
            "composite": {
                "type": "integer",
                "title": "Composite",
                "description": "How to stack copies in a repeater",
                "oneOf": [
                    {
                        "title": "Above",
                        "const": 1
                    },
                    {
                        "title": "Below",
                        "const": 2
                    }
                ]
            },
            "stroke-dash-type": {
                "type": "string",
                "title": "Stroke Dash Type",
                "description": "Type of a dash item in a stroked line",
                "oneOf": [
                    {
                        "title": "Dash",
                        "const": "d"
                    },
                    {
                        "title": "Gap",
                        "const": "g"
                    },
                    {
                        "title": "Offset",
                        "const": "o"
                    }
                ]
            },
            "text-shape": {
                "type": "integer",
                "title": "Text Shape",
                "description": "Defines the function used to determine the interpolating factor on a text range selector.",
                "oneOf": [
                    {
                        "title": "Square",
                        "const": 1
                    },
                    {
                        "title": "Ramp Up",
                        "const": 2
                    },
                    {
                        "title": "Ramp Down",
                        "const": 3
                    },
                    {
                        "title": "Triangle",
                        "const": 4
                    },
                    {
                        "title": "Round",
                        "const": 5
                    },
                    {
                        "title": "Smooth",
                        "const": 6
                    }
                ]
            },
            "blend-mode": {
                "type": "integer",
                "title": "Blend Mode",
                "description": "Layer and shape blend mode",
                "caniuse": "blend-mode",
                "oneOf": [
                    {
                        "title": "Normal",
                        "const": 0
                    },
                    {
                        "title": "Multiply",
                        "const": 1
                    },
                    {
                        "title": "Screen",
                        "const": 2
                    },
                    {
                        "title": "Overlay",
                        "const": 3
                    },
                    {
                        "title": "Darken",
                        "const": 4
                    },
                    {
                        "title": "Lighten",
                        "const": 5
                    },
                    {
                        "title": "Color Dodge",
                        "const": 6
                    },
                    {
                        "title": "Color Burn",
                        "const": 7
                    },
                    {
                        "title": "Hard Light",
                        "const": 8
                    },
                    {
                        "title": "Soft Light",
                        "const": 9
                    },
                    {
                        "title": "Difference",
                        "const": 10
                    },
                    {
                        "title": "Exclusion",
                        "const": 11
                    },
                    {
                        "title": "Hue",
                        "const": 12
                    },
                    {
                        "title": "Saturation",
                        "const": 13
                    },
                    {
                        "title": "Color",
                        "const": 14
                    },
                    {
                        "title": "Luminosity",
                        "const": 15
                    },
                    {
                        "title": "Add",
                        "const": 16
                    },
                    {
                        "title": "Hard Mix",
                        "const": 17
                    }
                ]
            },
            "line-cap": {
                "type": "integer",
                "title": "Line Cap",
                "description": "Style at the end of a stoked line",
                "oneOf": [
                    {
                        "title": "Butt",
                        "const": 1
                    },
                    {
                        "title": "Round",
                        "const": 2
                    },
                    {
                        "title": "Square",
                        "const": 3
                    }
                ]
            },
            "text-grouping": {
                "type": "integer",
                "title": "Text Grouping",
                "description": "",
                "oneOf": [
                    {
                        "title": "Characters",
                        "const": 1
                    },
                    {
                        "title": "Word",
                        "const": 2
                    },
                    {
                        "title": "Line",
                        "const": 3
                    },
                    {
                        "title": "All",
                        "const": 4
                    }
                ]
            },
            "shape-direction": {
                "type": "integer",
                "title": "Shape Direction",
                "description": "Drawing direction of the shape curve, useful for trim path",
                "oneOf": [
                    {
                        "title": "Normal",
                        "description": "Usually clockwise",
                        "const": 1
                    },
                    {
                        "title": "Reversed",
                        "description": "Usually counter clockwise",
                        "const": 3
                    }
                ]
            },
            "mask-mode": {
                "type": "string",
                "title": "Mask Mode",
                "description": "How masks interact with each other. See https://helpx.adobe.com/after-effects/using/alpha-channels-masks-mattes.html",
                "oneOf": [
                    {
                        "title": "None",
                        "const": "n"
                    },
                    {
                        "title": "Add",
                        "const": "a"
                    },
                    {
                        "title": "Subtract",
                        "const": "s"
                    },
                    {
                        "title": "Intersect",
                        "const": "i"
                    },
                    {
                        "title": "Lighten",
                        "const": "l"
                    },
                    {
                        "title": "Darken",
                        "const": "d"
                    },
                    {
                        "title": "Difference",
                        "const": "f"
                    }
                ]
            },
            "line-join": {
                "type": "integer",
                "title": "Line Join",
                "description": "Style at a sharp corner of a stoked line",
                "oneOf": [
                    {
                        "title": "Miter",
                        "const": 1
                    },
                    {
                        "title": "Round",
                        "const": 2
                    },
                    {
                        "title": "Bevel",
                        "const": 3
                    }
                ]
            },
            "gradient-type": {
                "type": "integer",
                "title": "Gradient Type",
                "description": "Type of a gradient",
                "oneOf": [
                    {
                        "title": "Linear",
                        "type": "integer",
                        "const": 1
                    },
                    {
                        "title": "Radial",
                        "type": "integer",
                        "const": 2
                    }
                ]
            },
            "text-justify": {
                "type": "integer",
                "title": "Text Justify",
                "description": "Text alignment / justification",
                "oneOf": [
                    {
                        "title": "Left",
                        "const": 0
                    },
                    {
                        "title": "Right",
                        "const": 1
                    },
                    {
                        "title": "Center",
                        "const": 2
                    },
                    {
                        "title": "Justify with Last Line Left",
                        "const": 3
                    },
                    {
                        "title": "Justify with Last Line Right",
                        "const": 4
                    },
                    {
                        "title": "Justify with Last Line Center",
                        "const": 5
                    },
                    {
                        "title": "Justify with Last Line Full",
                        "const": 6
                    }
                ]
            },
            "text-range-units": {
                "type": "integer",
                "title": "Text Range Units",
                "description": "Unit type for a text selector",
                "oneOf": [
                    {
                        "title": "Percent",
                        "const": 1
                    },
                    {
                        "title": "Index",
                        "const": 2
                    }
                ]
            },
            "text-caps": {
                "type": "integer",
                "title": "Text Caps",
                "oneOf": [
                    {
                        "title": "Regular",
                        "const": 0
                    },
                    {
                        "title": "All Caps",
                        "const": 1
                    },
                    {
                        "title": "Small Caps",
                        "const": 2
                    }
                ],
                "default": 0
            },
            "text-based": {
                "type": "integer",
                "title": "Text Based",
                "description": "",
                "oneOf": [
                    {
                        "title": "Characters",
                        "const": 1
                    },
                    {
                        "title": "Character Excluding Spaces",
                        "const": 2
                    },
                    {
                        "title": "Words",
                        "const": 3
                    },
                    {
                        "title": "Lines",
                        "const": 4
                    }
                ]
            },
            "star-type": {
                "type": "integer",
                "title": "Star Type",
                "description": "Star or Polygon",
                "oneOf": [
                    {
                        "title": "Star",
                        "const": 1
                    },
                    {
                        "title": "Polygon",
                        "const": 2
                    }
                ]
            },
            "matte-mode": {
                "type": "integer",
                "title": "Matte Mode",
                "description": "How a layer should mask another layer",
                "oneOf": [
                    {
                        "title": "Normal",
                        "const": 0
                    },
                    {
                        "title": "Alpha",
                        "const": 1
                    },
                    {
                        "title": "Inverted Alpha",
                        "const": 2
                    },
                    {
                        "title": "Luma",
                        "const": 3
                    },
                    {
                        "title": "Inverted Luma",
                        "const": 4
                    }
                ]
            },
            "font-path-origin": {
                "type": "integer",
                "title": "Font Path Origin",
                "description": "",
                "oneOf": [
                    {
                        "title": "Local",
                        "const": 0
                    },
                    {
                        "title": "Css Url",
                        "const": 1
                    },
                    {
                        "title": "Script Url",
                        "const": 2
                    },
                    {
                        "title": "Font Url",
                        "const": 3
                    }
                ]
            }
        },
        "effect-values": {
            "color": {
                "type": "object",
                "title": "Effect Value Color",
                "description": "",
                "allOf": [
                    {
                        "$ref": "#/$defs/effect-values/effect-value"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Type",
                                "type": "integer",
                                "const": 2
                            },
                            "v": {
                                "title": "Value",
                                "$ref": "#/$defs/animated-properties/color-value"
                            }
                        },
                        "required": [
                            "ty"
                        ]
                    }
                ]
            },
            "point": {
                "type": "object",
                "title": "Effect Value Point",
                "description": "",
                "allOf": [
                    {
                        "$ref": "#/$defs/effect-values/effect-value"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Type",
                                "type": "integer",
                                "const": 3
                            },
                            "v": {
                                "title": "Value",
                                "$ref": "#/$defs/animated-properties/multi-dimensional"
                            }
                        },
                        "required": [
                            "ty"
                        ]
                    }
                ]
            },
            "checkbox": {
                "type": "object",
                "title": "Effect Value Checkbox",
                "description": "",
                "allOf": [
                    {
                        "$ref": "#/$defs/effect-values/effect-value"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Type",
                                "type": "integer",
                                "const": 4
                            },
                            "v": {
                                "title": "Value",
                                "$ref": "#/$defs/animated-properties/value"
                            }
                        },
                        "required": [
                            "ty"
                        ]
                    }
                ]
            },
            "drop-down": {
                "type": "object",
                "title": "Effect Value Drop Down",
                "description": "",
                "allOf": [
                    {
                        "$ref": "#/$defs/effect-values/effect-value"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Type",
                                "type": "integer",
                                "const": 7
                            },
                            "v": {
                                "title": "Value",
                                "$ref": "#/$defs/animated-properties/value"
                            }
                        },
                        "required": [
                            "ty"
                        ]
                    }
                ]
            },
            "slider": {
                "type": "object",
                "title": "Effect Value Slider",
                "description": "",
                "allOf": [
                    {
                        "$ref": "#/$defs/effect-values/effect-value"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Type",
                                "type": "integer",
                                "const": 0
                            },
                            "v": {
                                "title": "Value",
                                "$ref": "#/$defs/animated-properties/value"
                            }
                        },
                        "required": [
                            "ty"
                        ]
                    }
                ]
            },
            "no-value": {
                "type": "object",
                "title": "Effect No Value",
                "description": ""
            },
            "angle": {
                "type": "object",
                "title": "Effect Value Angle",
                "description": "",
                "allOf": [
                    {
                        "$ref": "#/$defs/effect-values/effect-value"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Type",
                                "type": "integer",
                                "const": 1
                            },
                            "v": {
                                "title": "Value",
                                "$ref": "#/$defs/animated-properties/value"
                            }
                        },
                        "required": [
                            "ty"
                        ]
                    }
                ]
            },
            "layer": {
                "type": "object",
                "title": "Effect Value Layer",
                "description": "",
                "allOf": [
                    {
                        "$ref": "#/$defs/effect-values/effect-value"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Type",
                                "type": "integer",
                                "const": 10
                            },
                            "v": {
                                "title": "Value",
                                "$ref": "#/$defs/animated-properties/value"
                            }
                        },
                        "required": [
                            "ty"
                        ]
                    }
                ]
            },
            "effect-value": {
                "type": "object",
                "title": "Effect Value",
                "description": "Value for an effect",
                "caniuse": "effects",
                "allOf": [
                    {
                        "$ref": "#/$defs/helpers/visual-object"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ix": {
                                "title": "Effect Index",
                                "type": "integer"
                            },
                            "mn": {
                                "title": "Match Name",
                                "type": "string"
                            },
                            "nm": {
                                "title": "Name",
                                "type": "string"
                            },
                            "ty": {
                                "title": "Type",
                                "type": "integer"
                            }
                        },
                        "required": []
                    }
                ]
            },
            "ignored": {
                "type": "object",
                "title": "Ignored Value",
                "description": "",
                "allOf": [
                    {
                        "$ref": "#/$defs/effect-values/effect-value"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Type",
                                "type": "integer",
                                "const": 6
                            },
                            "v": {
                                "title": "Value",
                                "type": "number",
                                "default": 0
                            }
                        },
                        "required": [
                            "ty"
                        ]
                    }
                ]
            }
        },
        "effects": {
            "twirl-effect": {
                "type": "object",
                "title": "Twirl Effect",
                "description": "",
                "allOf": [
                    {
                        "$ref": "#/$defs/effects/effect"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Type",
                                "type": "integer",
                                "const": 30
                            },
                            "ef": {
                                "title": "Effect values",
                                "type": "array",
                                "prefixItems": [
                                    {
                                        "title": "Angle",
                                        "$ref": "#/$defs/effect-values/angle"
                                    },
                                    {
                                        "title": "Radius",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "Center",
                                        "$ref": "#/$defs/effect-values/point"
                                    }
                                ]
                            }
                        },
                        "required": [
                            "ty",
                            "ef"
                        ]
                    }
                ]
            },
            "pro-levels-effect": {
                "type": "object",
                "title": "Pro Levels Effect",
                "description": "",
                "caniuse": "effect-color-levels-individual-controls",
                "allOf": [
                    {
                        "$ref": "#/$defs/effects/effect"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Type",
                                "type": "integer",
                                "const": 24
                            },
                            "ef": {
                                "title": "Effect values",
                                "type": "array",
                                "prefixItems": [
                                    {
                                        "title": "00",
                                        "$ref": "#/$defs/effect-values/drop-down"
                                    },
                                    {
                                        "title": "01",
                                        "$ref": "#/$defs/effect-values/no-value"
                                    },
                                    {
                                        "title": "02",
                                        "$ref": "#/$defs/effect-values/no-value"
                                    },
                                    {
                                        "title": "comp_inblack",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "comp_inwhite",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "comp_gamma",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "comp_outblack",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "comp_outwhite",
                                        "$ref": "#/$defs/effect-values/no-value"
                                    },
                                    {
                                        "title": "08",
                                        "$ref": "#/$defs/effect-values/no-value"
                                    },
                                    {
                                        "title": "09",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "r_inblack",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "r_inwhite",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "r_gamma",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "r_outblack",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "r_outwhite",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "15",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "16",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "g_inblack",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "g_inwhite",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "g_gamma",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "g_outblack",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "g_outwhite",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "22",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "23",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "b_inblack",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "b_inwhite",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "b_gamma",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "b_outblack",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "b_outwhite",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "29",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "a_inblack",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "a_inwhite",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "a_gamma",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "a_outblack",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "a_outwhite",
                                        "$ref": "#/$defs/effect-values/no-value"
                                    }
                                ]
                            }
                        },
                        "required": [
                            "ty"
                        ]
                    }
                ]
            },
            "gaussian-blur-effect": {
                "type": "object",
                "title": "Gaussian Blur Effect",
                "description": "Gaussian blur",
                "caniuse": "effect-gaussian-blur",
                "allOf": [
                    {
                        "$ref": "#/$defs/effects/effect"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Type",
                                "type": "integer",
                                "const": 29
                            },
                            "ef": {
                                "title": "Effect values",
                                "type": "array",
                                "prefixItems": [
                                    {
                                        "title": "sigma",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "direction",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "wrap",
                                        "$ref": "#/$defs/effect-values/checkbox"
                                    }
                                ]
                            }
                        },
                        "required": [
                            "ty"
                        ]
                    }
                ]
            },
            "stroke-effect": {
                "type": "object",
                "title": "Stroke Effect",
                "description": "",
                "caniuse": "effect-stroke",
                "allOf": [
                    {
                        "$ref": "#/$defs/effects/effect"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Type",
                                "type": "integer",
                                "const": 22
                            },
                            "ef": {
                                "title": "Effect values",
                                "type": "array",
                                "prefixItems": [
                                    {
                                        "title": "00",
                                        "$ref": "#/$defs/effect-values/color"
                                    },
                                    {
                                        "title": "01",
                                        "$ref": "#/$defs/effect-values/checkbox"
                                    },
                                    {
                                        "title": "02",
                                        "$ref": "#/$defs/effect-values/checkbox"
                                    },
                                    {
                                        "title": "color",
                                        "$ref": "#/$defs/effect-values/color"
                                    },
                                    {
                                        "title": "04",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "05",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "06",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "07",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "08",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "09",
                                        "$ref": "#/$defs/effect-values/drop-down"
                                    },
                                    {
                                        "title": "type",
                                        "$ref": "#/$defs/effect-values/drop-down"
                                    }
                                ]
                            }
                        },
                        "required": [
                            "ty"
                        ]
                    }
                ]
            },
            "tritone-effect": {
                "type": "object",
                "title": "Tritone Effect",
                "description": "Maps layers colors based on bright/mid/dark colors",
                "caniuse": "effect-tritone",
                "allOf": [
                    {
                        "$ref": "#/$defs/effects/effect"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Type",
                                "type": "integer",
                                "const": 23
                            },
                            "ef": {
                                "title": "Effect values",
                                "type": "array",
                                "prefixItems": [
                                    {
                                        "title": "bright",
                                        "$ref": "#/$defs/effect-values/color"
                                    },
                                    {
                                        "title": "mid",
                                        "$ref": "#/$defs/effect-values/color"
                                    },
                                    {
                                        "title": "dark",
                                        "$ref": "#/$defs/effect-values/color"
                                    }
                                ]
                            }
                        },
                        "required": [
                            "ty"
                        ]
                    }
                ]
            },
            "drop-shadow-effect": {
                "type": "object",
                "title": "Drop Shadow Effect",
                "description": "Adds a shadow to the layer",
                "caniuse": "effect-drop-shadow",
                "allOf": [
                    {
                        "$ref": "#/$defs/effects/effect"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Type",
                                "type": "integer",
                                "const": 25
                            },
                            "ef": {
                                "title": "Effect values",
                                "type": "array",
                                "prefixItems": [
                                    {
                                        "title": "color",
                                        "$ref": "#/$defs/effect-values/color"
                                    },
                                    {
                                        "title": "opacity",
                                        "description": "Opacity between 0 and 255",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "angle",
                                        "$ref": "#/$defs/effect-values/angle"
                                    },
                                    {
                                        "title": "distance",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "blur",
                                        "$ref": "#/$defs/effect-values/slider"
                                    }
                                ]
                            }
                        },
                        "required": [
                            "ty"
                        ]
                    }
                ]
            },
            "wavy-effect": {
                "type": "object",
                "title": "Wavy Effect",
                "description": "",
                "allOf": [
                    {
                        "$ref": "#/$defs/effects/effect"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Type",
                                "type": "integer",
                                "const": 32
                            },
                            "ef": {
                                "title": "Effect values",
                                "type": "array",
                                "prefixItems": [
                                    {
                                        "title": "Radius",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "Center",
                                        "$ref": "#/$defs/effect-values/point"
                                    },
                                    {
                                        "title": "Conversion type",
                                        "$ref": "#/$defs/effect-values/drop-down"
                                    },
                                    {
                                        "title": "Speed",
                                        "$ref": "#/$defs/effect-values/drop-down"
                                    },
                                    {
                                        "title": "Width",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "Height",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "Phase",
                                        "$ref": "#/$defs/effect-values/slider"
                                    }
                                ]
                            }
                        },
                        "required": [
                            "ty",
                            "ef"
                        ]
                    }
                ]
            },
            "spherize-effect": {
                "type": "object",
                "title": "Spherize Effect",
                "description": "",
                "caniuse": "effect-cc-sphere",
                "allOf": [
                    {
                        "$ref": "#/$defs/effects/effect"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Type",
                                "type": "integer",
                                "const": 33
                            },
                            "ef": {
                                "title": "Effect values",
                                "type": "array",
                                "prefixItems": [
                                    {
                                        "title": "radius",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "center",
                                        "$ref": "#/$defs/effect-values/point"
                                    }
                                ]
                            }
                        },
                        "required": [
                            "ty"
                        ]
                    }
                ]
            },
            "matte3-effect": {
                "type": "object",
                "title": "Set Matte Effect",
                "description": "Uses a layer as a mask",
                "allOf": [
                    {
                        "$ref": "#/$defs/effects/effect"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Type",
                                "type": "integer",
                                "const": 28
                            },
                            "ef": {
                                "title": "Effect values",
                                "type": "array",
                                "prefixItems": [
                                    {
                                        "title": "Layer",
                                        "description": "Use this layer as a mask",
                                        "$ref": "#/$defs/effect-values/layer"
                                    },
                                    {
                                        "title": "Channel",
                                        "description": "Channel to use as a mask:\n1 - Red\n2 - Green\n3 - Blue\n4 - Alpha\n5 - Luminance\n6 - Hue\n7 - Lightness\n8 - Saturation\n9 - Full\n10 - Off",
                                        "$ref": "#/$defs/effect-values/drop-down"
                                    },
                                    {
                                        "title": "Invert",
                                        "description": "Use 0 as opaque value when true",
                                        "$ref": "#/$defs/effect-values/drop-down"
                                    },
                                    {
                                        "title": "Stretch To Fit",
                                        "$ref": "#/$defs/effect-values/drop-down"
                                    },
                                    {
                                        "title": "Show Mask",
                                        "description": "If false, the mask layer won't be shown",
                                        "$ref": "#/$defs/effect-values/drop-down"
                                    },
                                    {
                                        "title": "Premultiply Mask",
                                        "$ref": "#/$defs/effect-values/drop-down"
                                    }
                                ]
                            }
                        },
                        "required": [
                            "ty"
                        ]
                    }
                ]
            },
            "custom-effect": {
                "type": "object",
                "title": "Custom Effect",
                "description": "Some lottie files use `ty` = 5 for many different effects",
                "allOf": [
                    {
                        "$ref": "#/$defs/effects/effect"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Type",
                                "type": "integer",
                                "const": 5
                            }
                        },
                        "required": [
                            "ty"
                        ]
                    }
                ]
            },
            "mesh-warp-effect": {
                "type": "object",
                "title": "Mesh Warp Effect",
                "description": "",
                "allOf": [
                    {
                        "$ref": "#/$defs/effects/effect"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Type",
                                "type": "integer",
                                "const": 31
                            },
                            "ef": {
                                "title": "Effect values",
                                "type": "array",
                                "prefixItems": [
                                    {
                                        "title": "Rows",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "Columns",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "Quality",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "03",
                                        "$ref": "#/$defs/effect-values/no-value"
                                    }
                                ]
                            }
                        },
                        "required": [
                            "ty",
                            "ef"
                        ]
                    }
                ]
            },
            "radial-wipe-effect": {
                "type": "object",
                "title": "Radial Wipe",
                "caniuse": "effect-radial-wipe",
                "allOf": [
                    {
                        "$ref": "#/$defs/effects/effect"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Type",
                                "type": "integer",
                                "const": 26
                            },
                            "ef": {
                                "title": "Effect values",
                                "type": "array",
                                "prefixItems": [
                                    {
                                        "title": "Completion",
                                        "description": "Between 0 and 100",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "Start Angle",
                                        "$ref": "#/$defs/effect-values/angle"
                                    },
                                    {
                                        "title": "Wipe Center",
                                        "$ref": "#/$defs/effect-values/point"
                                    },
                                    {
                                        "title": "Wipe",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "Feather",
                                        "$ref": "#/$defs/effect-values/slider"
                                    }
                                ]
                            }
                        },
                        "required": [
                            "ty"
                        ]
                    }
                ]
            },
            "fill-effect": {
                "type": "object",
                "title": "Fill Effect",
                "description": "Replaces the whole layer with the given color",
                "caniuse": "effect-fill",
                "allOf": [
                    {
                        "$ref": "#/$defs/effects/effect"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Type",
                                "type": "integer",
                                "const": 21
                            },
                            "ef": {
                                "title": "Effect values",
                                "type": "array",
                                "prefixItems": [
                                    {
                                        "title": "00",
                                        "$ref": "#/$defs/effect-values/point"
                                    },
                                    {
                                        "title": "01",
                                        "$ref": "#/$defs/effect-values/drop-down"
                                    },
                                    {
                                        "title": "color",
                                        "$ref": "#/$defs/effect-values/color"
                                    },
                                    {
                                        "title": "03",
                                        "$ref": "#/$defs/effect-values/drop-down"
                                    },
                                    {
                                        "title": "04",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "05",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "opacity",
                                        "description": "Opacity in [0, 1]",
                                        "$ref": "#/$defs/effect-values/slider"
                                    }
                                ]
                            }
                        },
                        "required": [
                            "ty"
                        ]
                    }
                ]
            },
            "effect": {
                "type": "object",
                "title": "Effect",
                "description": "Layer effect",
                "caniuse": "effects",
                "allOf": [
                    {
                        "$ref": "#/$defs/helpers/visual-object"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ef": {
                                "title": "Effect Values",
                                "type": "array",
                                "items": {
                                    "oneOf": [
                                        {
                                            "$ref": "#/$defs/effect-values/no-value"
                                        },
                                        {
                                            "$ref": "#/$defs/effect-values/angle"
                                        },
                                        {
                                            "$ref": "#/$defs/effect-values/checkbox"
                                        },
                                        {
                                            "$ref": "#/$defs/effect-values/color"
                                        },
                                        {
                                            "$ref": "#/$defs/effect-values/drop-down"
                                        },
                                        {
                                            "$ref": "#/$defs/effect-values/ignored"
                                        },
                                        {
                                            "$ref": "#/$defs/effect-values/layer"
                                        },
                                        {
                                            "$ref": "#/$defs/effect-values/point"
                                        },
                                        {
                                            "$ref": "#/$defs/effect-values/slider"
                                        }
                                    ]
                                }
                            },
                            "np": {
                                "title": "Property Count",
                                "description": "Number of values in `ef`",
                                "type": "integer"
                            },
                            "ix": {
                                "title": "Effect Index",
                                "type": "integer"
                            },
                            "ty": {
                                "title": "Type",
                                "description": "Effect type",
                                "type": "integer"
                            },
                            "en": {
                                "title": "Enabled",
                                "$ref": "#/$defs/helpers/int-boolean",
                                "default": 1
                            }
                        },
                        "required": [
                            "ty",
                            "ef"
                        ]
                    }
                ]
            },
            "tint-effect": {
                "type": "object",
                "title": "Tint Effect",
                "description": "Colorizes the layer",
                "caniuse": "effect-tint",
                "allOf": [
                    {
                        "$ref": "#/$defs/effects/effect"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Type",
                                "type": "integer",
                                "const": 20
                            },
                            "ef": {
                                "title": "Effect values",
                                "type": "array",
                                "prefixItems": [
                                    {
                                        "title": "Black Color",
                                        "description": "Tint of the darker parts of the layer",
                                        "$ref": "#/$defs/effect-values/color"
                                    },
                                    {
                                        "title": "White Color",
                                        "description": "Tint of the lighter parts of the layer",
                                        "$ref": "#/$defs/effect-values/color"
                                    },
                                    {
                                        "title": "Intensity",
                                        "description": "Intensity of the effect, 0 means the layer is unchanged. 100 means full effect",
                                        "$ref": "#/$defs/effect-values/slider"
                                    }
                                ]
                            }
                        },
                        "required": [
                            "ty"
                        ]
                    }
                ]
            },
            "puppet-effect": {
                "type": "object",
                "title": "Puppet Effect",
                "description": "",
                "allOf": [
                    {
                        "$ref": "#/$defs/effects/effect"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Type",
                                "type": "integer",
                                "const": 34
                            },
                            "ef": {
                                "title": "Effect values",
                                "type": "array",
                                "prefixItems": [
                                    {
                                        "title": "Puppet Engine",
                                        "$ref": "#/$defs/effect-values/drop-down"
                                    },
                                    {
                                        "title": "Mesh Rotation Refinement",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "On Transparent",
                                        "$ref": "#/$defs/effect-values/drop-down"
                                    },
                                    {
                                        "title": "03",
                                        "$ref": "#/$defs/effect-values/no-value"
                                    }
                                ]
                            }
                        },
                        "required": [
                            "ty",
                            "ef"
                        ]
                    }
                ]
            },
            "displacement-map-effect": {
                "type": "object",
                "title": "Displacement Map Effect",
                "description": "",
                "caniuse": "effect-displacement-map",
                "allOf": [
                    {
                        "$ref": "#/$defs/effects/effect"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Type",
                                "type": "integer",
                                "const": 27
                            },
                            "ef": {
                                "title": "Effect values",
                                "type": "array",
                                "prefixItems": [
                                    {
                                        "title": "Displacement Map Layer",
                                        "$ref": "#/$defs/effect-values/layer"
                                    },
                                    {
                                        "title": "Use For Horizontal Displacement",
                                        "$ref": "#/$defs/effect-values/drop-down"
                                    },
                                    {
                                        "title": "Max Horizontal Displacement",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "Use For Vertical Displacement",
                                        "$ref": "#/$defs/effect-values/drop-down"
                                    },
                                    {
                                        "title": "Max Vertical Displacement",
                                        "$ref": "#/$defs/effect-values/slider"
                                    },
                                    {
                                        "title": "Displacement Map Behavior",
                                        "$ref": "#/$defs/effect-values/drop-down"
                                    },
                                    {
                                        "title": "Edge Behavior",
                                        "$ref": "#/$defs/effect-values/drop-down"
                                    },
                                    {
                                        "title": "Expand Output",
                                        "$ref": "#/$defs/effect-values/drop-down"
                                    }
                                ]
                            }
                        },
                        "required": [
                            "ty",
                            "ef"
                        ]
                    }
                ]
            }
        },
        "helpers": {
            "color": {
                "type": "array",
                "title": "Color",
                "description": "Color as a [r, g, b] array with values in [0, 1]",
                "items": {
                    "type": "number",
                    "minimum": 0,
                    "maximum": 1
                },
                "minItems": 3,
                "maxItems": 4
            },
            "int-boolean": {
                "type": "integer",
                "title": "Integer Boolean",
                "description": "Represents boolean values as an integer. 0 is false, 1 is true.",
                "default": 0,
                "examples": [
                    0
                ],
                "enum": [
                    0,
                    1
                ],
                "oneOf": [
                    {
                        "title": "True",
                        "const": 1
                    },
                    {
                        "title": "False",
                        "const": 0
                    }
                ]
            },
            "transform": {
                "type": "object",
                "title": "Transform",
                "description": "Layer transform",
                "allOf": [
                    {
                        "properties": {
                            "a": {
                                "title": "Anchor Point",
                                "caniuse": "transform-anchor-point",
                                "description": "Anchor point: a position (relative to its parent) around which transformations are applied (ie: center for rotation / scale)",
                                "$ref": "#/$defs/animated-properties/position"
                            },
                            "s": {
                                "title": "Scale",
                                "caniuse": "transform-scale",
                                "description": "Scale factor, `[100, 100]` for no scaling",
                                "$ref": "#/$defs/animated-properties/multi-dimensional"
                            },
                            "o": {
                                "title": "Opacity",
                                "caniuse": "transform-opacity",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "sk": {
                                "title": "Skew",
                                "caniuse": "transform-skew",
                                "description": "Skew amount as an angle in degrees",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "sa": {
                                "title": "Skew Axis",
                                "caniuse": "transform-skew",
                                "description": "Direction along which skew is applied, in degrees (`0` skews along the X axis, `90` along the Y axis)",
                                "$ref": "#/$defs/animated-properties/value"
                            }
                        }
                    },
                    {
                        "anyOf": [
                            {
                                "oneOf": [
                                    {
                                        "properties": {
                                            "p": {
                                                "title": "Position",
                                                "caniuse": "transform-position",
                                                "description": "Position / Translation",
                                                "$ref": "#/$defs/animated-properties/position"
                                            }
                                        }
                                    },
                                    {
                                        "properties": {
                                            "p": {
                                                "title": "Position",
                                                "description": "Position / Translation with split components",
                                                "$ref": "#/$defs/animated-properties/split-vector"
                                            }
                                        }
                                    }
                                ]
                            },
                            {
                                "oneOf": [
                                    {
                                        "properties": {
                                            "r": {
                                                "title": "Rotation",
                                                "caniuse": "transform-rotation",
                                                "description": "Rotation in degrees, clockwise",
                                                "$ref": "#/$defs/animated-properties/value"
                                            }
                                        }
                                    },
                                    {
                                        "properties": {
                                            "rx": {
                                                "title": "X Rotation",
                                                "description": "Split rotation component",
                                                "$ref": "#/$defs/animated-properties/value"
                                            },
                                            "ry": {
                                                "title": "Y Rotation",
                                                "description": "Split rotation component",
                                                "$ref": "#/$defs/animated-properties/value"
                                            },
                                            "rz": {
                                                "title": "Z Rotation",
                                                "description": "Split rotation component, equivalent to `r` when not split",
                                                "$ref": "#/$defs/animated-properties/value"
                                            },
                                            "or": {
                                                "title": "Orientation",
                                                "$ref": "#/$defs/animated-properties/multi-dimensional"
                                            }
                                        }
                                    }
                                ]
                            }
                        ]
                    }
                ]
            },
            "bezier": {
                "type": "object",
                "title": "Bezier",
                "description": "Single bezier curve",
                "properties": {
                    "c": {
                        "title": "Closed",
                        "type": "boolean",
                        "default": false
                    },
                    "i": {
                        "title": "In Tangents",
                        "type": "array",
                        "description": "Array of points, each point is an array of coordinates.\nThese points are along the `in` tangents relative to the corresponding `v`.",
                        "items": {
                            "type": "array",
                            "items": {
                                "type": "number",
                                "default": []
                            }
                        }
                    },
                    "o": {
                        "title": "Out Tangents",
                        "type": "array",
                        "description": "Array of points, each point is an array of coordinates.\nThese points are along the `out` tangents relative to the corresponding `v`.",
                        "items": {
                            "type": "array",
                            "items": {
                                "type": "number",
                                "default": []
                            }
                        }
                    },
                    "v": {
                        "title": "Vertices",
                        "description": "Array of points, each point is an array of coordinates.\nThese points are along the bezier path",
                        "type": "array",
                        "items": {
                            "type": "array",
                            "items": {
                                "type": "number",
                                "default": []
                            }
                        }
                    }
                },
                "required": [
                    "i",
                    "v",
                    "o"
                ]
            },
            "mask": {
                "type": "object",
                "title": "Mask",
                "caniuse": "mask",
                "description": "Bezier shape used to mask/clip a layer",
                "allOf": [
                    {
                        "$ref": "#/$defs/helpers/visual-object"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "inv": {
                                "title": "Inverted",
                                "caniuse": "mask-inverted",
                                "type": "boolean",
                                "default": false
                            },
                            "pt": {
                                "title": "Shape",
                                "$ref": "#/$defs/animated-properties/shape-property"
                            },
                            "o": {
                                "title": "Opacity",
                                "caniuse": "mask-opacity",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "mode": {
                                "title": "Mode",
                                "caniuse": "mask-modes",
                                "$ref": "#/$defs/constants/mask-mode",
                                "default": "i"
                            },
                            "x": {
                                "title": "Expand",
                                "caniuse": "mask-expansion",
                                "$ref": "#/$defs/animated-properties/value"
                            }
                        },
                        "required": []
                    }
                ]
            },
            "visual-object": {
                "type": "object",
                "title": "Visual Object",
                "description": "",
                "allOf": [
                    {
                        "type": "object",
                        "properties": {
                            "nm": {
                                "title": "Name",
                                "description": "Name, as seen from editors and the like",
                                "type": "string"
                            },
                            "mn": {
                                "title": "Match Name",
                                "description": "Match name, used in expressions",
                                "type": "string"
                            }
                        },
                        "required": []
                    }
                ]
            },
            "marker": {
                "type": "object",
                "title": "Marker",
                "description": "Defines named portions of the composition.",
                "properties": {
                    "cm": {
                        "title": "Comment",
                        "type": "string"
                    },
                    "tm": {
                        "title": "Time",
                        "type": "number"
                    },
                    "dr": {
                        "title": "Duration",
                        "type": "number"
                    }
                }
            }
        },
        "layers": {
            "null-layer": {
                "type": "object",
                "title": "Null Layer",
                "description": "Layer with no data, useful to group layers together",
                "allOf": [
                    {
                        "$ref": "#/$defs/layers/visual-layer"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Type",
                                "description": "Layer type",
                                "type": "integer",
                                "const": 3
                            }
                        },
                        "required": [
                            "ty"
                        ]
                    }
                ]
            },
            "data-layer": {
                "type": "object",
                "title": "Data Layer",
                "allOf": [
                    {
                        "$ref": "#/$defs/layers/layer"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Type",
                                "description": "Layer type",
                                "type": "integer",
                                "const": 15
                            },
                            "refId": {
                                "title": "Data source Id",
                                "description": "ID of the data source in assets",
                                "type": "string"
                            }
                        },
                        "required": [
                            "ty"
                        ]
                    }
                ]
            },
            "image-layer": {
                "type": "object",
                "title": "Image Layer",
                "description": "Layer that shows an image asset",
                "caniuse": "layer-image",
                "allOf": [
                    {
                        "$ref": "#/$defs/layers/visual-layer"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Type",
                                "description": "Layer type",
                                "type": "integer",
                                "const": 2
                            },
                            "refId": {
                                "title": "Image Id",
                                "description": "ID of the image as specified in the assets",
                                "type": "string",
                                "default": ""
                            }
                        },
                        "required": [
                            "ty",
                            "refId"
                        ]
                    }
                ]
            },
            "precomposition-layer": {
                "type": "object",
                "title": "Precomposition Layer",
                "description": "Layer that renders a Precomposition asset",
                "caniuse": "layer-precomp",
                "allOf": [
                    {
                        "$ref": "#/$defs/layers/visual-layer"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Type",
                                "description": "Layer type",
                                "type": "integer",
                                "const": 0
                            },
                            "refId": {
                                "title": "Reference Id",
                                "description": "ID of the precomp as specified in the assets",
                                "type": "string"
                            },
                            "w": {
                                "title": "Width",
                                "description": "Width of the clipping rect",
                                "type": "integer"
                            },
                            "h": {
                                "title": "Height",
                                "description": "Height of the clipping rect",
                                "type": "integer"
                            },
                            "tm": {
                                "title": "Time Remapping",
                                "caniuse": "property-timeremap",
                                "$ref": "#/$defs/animated-properties/value"
                            }
                        },
                        "required": [
                            "ty",
                            "refId",
                            "w",
                            "h"
                        ]
                    }
                ]
            },
            "camera-layer": {
                "type": "object",
                "title": "Camera Layer",
                "description": "3D Camera",
                "allOf": [
                    {
                        "$ref": "#/$defs/layers/layer"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Type",
                                "description": "Layer type",
                                "type": "integer",
                                "const": 13
                            },
                            "ks": {
                                "title": "Transform",
                                "description": "Layer transform",
                                "$ref": "#/$defs/helpers/transform"
                            },
                            "pe": {
                                "title": "Perspective",
                                "description": "Distance from the Z=0 plane.\nSmall values yield a higher perspective effect.",
                                "$ref": "#/$defs/animated-properties/value"
                            }
                        },
                        "required": [
                            "ty",
                            "ks",
                            "pe"
                        ]
                    }
                ]
            },
            "audio-layer": {
                "type": "object",
                "title": "Audio Layer",
                "description": "A layer playing sounds",
                "allOf": [
                    {
                        "$ref": "#/$defs/layers/layer"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Type",
                                "description": "Layer type",
                                "type": "integer",
                                "const": 6
                            },
                            "au": {
                                "title": "Audio Settings",
                                "$ref": "#/$defs/layers/audio-settings"
                            },
                            "refId": {
                                "title": "Sound Id",
                                "description": "ID of the sound as specified in the assets",
                                "type": "string"
                            }
                        },
                        "required": [
                            "ty",
                            "au"
                        ]
                    }
                ]
            },
            "visual-layer": {
                "type": "object",
                "title": "Visual Layer",
                "description": "Layer used to affect visual elements",
                "allOf": [
                    {
                        "$ref": "#/$defs/layers/layer"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "cp": {
                                "title": "Collapse Transform",
                                "type": "boolean"
                            },
                            "ks": {
                                "title": "Transform",
                                "caniuse": "transform",
                                "description": "Layer transform",
                                "$ref": "#/$defs/helpers/transform"
                            },
                            "ao": {
                                "title": "Auto Orient",
                                "$ref": "#/$defs/helpers/int-boolean",
                                "default": 0,
                                "description": "If 1, The layer will rotate itself to match its animated position path"
                            },
                            "tt": {
                                "title": "Matte Mode",
                                "caniuse": "property-matte-mask",
                                "$ref": "#/$defs/constants/matte-mode",
                                "description": "Defines the track matte mode for the layer"
                            },
                            "tp": {
                                "title": "Matte Parent",
                                "type": "integer",
                                "description": "Index of the layer used as matte, if omitted assume the layer above the current one"
                            },
                            "td": {
                                "title": "Matte Target",
                                "caniuse": "property-matte-mask",
                                "$ref": "#/$defs/helpers/int-boolean",
                                "description": "If set to 1, it means a layer is using this layer as a track matte"
                            },
                            "hasMask": {
                                "title": "Has Masks",
                                "caniuse": "mask",
                                "description": "Whether the layer has masks applied",
                                "type": "boolean"
                            },
                            "masksProperties": {
                                "title": "Masks",
                                "caniuse": "mask",
                                "type": "array",
                                "items": {
                                    "$ref": "#/$defs/helpers/mask"
                                }
                            },
                            "ef": {
                                "title": "Effects",
                                "description": "List of layer effects",
                                "caniuse": "effects",
                                "type": "array",
                                "items": {
                                    "oneOf": [
                                        {
                                            "$ref": "#/$defs/effects/custom-effect"
                                        },
                                        {
                                            "$ref": "#/$defs/effects/drop-shadow-effect"
                                        },
                                        {
                                            "$ref": "#/$defs/effects/fill-effect"
                                        },
                                        {
                                            "$ref": "#/$defs/effects/gaussian-blur-effect"
                                        },
                                        {
                                            "$ref": "#/$defs/effects/matte3-effect"
                                        },
                                        {
                                            "$ref": "#/$defs/effects/pro-levels-effect"
                                        },
                                        {
                                            "$ref": "#/$defs/effects/stroke-effect"
                                        },
                                        {
                                            "$ref": "#/$defs/effects/tint-effect"
                                        },
                                        {
                                            "$ref": "#/$defs/effects/tritone-effect"
                                        },
                                        {
                                            "$ref": "#/$defs/effects/radial-wipe-effect"
                                        },
                                        {
                                            "$ref": "#/$defs/effects/wavy-effect"
                                        },
                                        {
                                            "$ref": "#/$defs/effects/puppet-effect"
                                        },
                                        {
                                            "$ref": "#/$defs/effects/spherize-effect"
                                        },
                                        {
                                            "$ref": "#/$defs/effects/mesh-warp-effect"
                                        },
                                        {
                                            "$ref": "#/$defs/effects/displacement-map-effect"
                                        },
                                        {
                                            "$ref": "#/$defs/effects/twirl-effect"
                                        }
                                    ]
                                }
                            },
                            "mb": {
                                "title": "Motion Blur",
                                "description": "Whether motion blur is enabled for the layer",
                                "type": "boolean"
                            },
                            "sy": {
                                "title": "Layer style",
                                "caniuse": "styles",
                                "description": "Styling effects for this layer",
                                "type": "array",
                                "items": {
                                    "oneOf": [
                                        {
                                            "$ref": "#/$defs/styles/stroke-style"
                                        },
                                        {
                                            "$ref": "#/$defs/styles/drop-shadow-style"
                                        },
                                        {
                                            "$ref": "#/$defs/styles/inner-shadow-style"
                                        },
                                        {
                                            "$ref": "#/$defs/styles/outer-glow-style"
                                        },
                                        {
                                            "$ref": "#/$defs/styles/inner-glow-style"
                                        },
                                        {
                                            "$ref": "#/$defs/styles/bevel-emboss-style"
                                        },
                                        {
                                            "$ref": "#/$defs/styles/satin-style"
                                        },
                                        {
                                            "$ref": "#/$defs/styles/color-overlay-style"
                                        },
                                        {
                                            "$ref": "#/$defs/styles/gradient-overlay-style"
                                        }
                                    ]
                                }
                            },
                            "bm": {
                                "title": "Blend Mode",
                                "$ref": "#/$defs/constants/blend-mode",
                                "default": 0
                            },
                            "cl": {
                                "title": "CSS Class",
                                "description": "CSS class used by the SVG renderer",
                                "type": "string"
                            },
                            "ln": {
                                "title": "Layer XML ID",
                                "description": "`id` attribute used by the SVG renderer",
                                "type": "string"
                            },
                            "tg": {
                                "title": "Layer XML tag name",
                                "description": "tag name used by the SVG renderer",
                                "type": "string"
                            }
                        },
                        "required": [
                            "ks"
                        ]
                    }
                ]
            },
            "shape-layer": {
                "type": "object",
                "title": "Shape Layer",
                "description": "Layer containing Shapes",
                "caniuse": "layer-shape",
                "allOf": [
                    {
                        "$ref": "#/$defs/layers/visual-layer"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Type",
                                "description": "Layer type",
                                "type": "integer",
                                "const": 4
                            },
                            "shapes": {
                                "title": "Shapes",
                                "$ref": "#/$defs/shapes/shape-list"
                            }
                        },
                        "required": [
                            "ty",
                            "shapes"
                        ]
                    }
                ]
            },
            "solid-color-layer": {
                "type": "object",
                "title": "Solid Color Layer",
                "description": "Layer with a solid color rectangle",
                "caniuse": "layer-solid",
                "allOf": [
                    {
                        "$ref": "#/$defs/layers/visual-layer"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Type",
                                "description": "Layer type",
                                "type": "integer",
                                "const": 1
                            },
                            "sc": {
                                "title": "Color",
                                "description": "Color of the layer, unlike most other places, the color is a `#rrggbb` hex string",
                                "type": "string",
                                "default": ""
                            },
                            "sh": {
                                "title": "Height",
                                "type": "number"
                            },
                            "sw": {
                                "title": "Width",
                                "type": "number"
                            }
                        },
                        "required": [
                            "ty",
                            "sc",
                            "sw",
                            "sh"
                        ]
                    }
                ]
            },
            "text-layer": {
                "type": "object",
                "title": "Text Layer",
                "description": "Layer with some text",
                "caniuse": "layer-text",
                "allOf": [
                    {
                        "$ref": "#/$defs/layers/visual-layer"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Type",
                                "description": "Layer type",
                                "type": "integer",
                                "const": 5
                            },
                            "t": {
                                "title": "Data",
                                "$ref": "#/$defs/text/text-data"
                            }
                        },
                        "required": [
                            "ty",
                            "t"
                        ]
                    }
                ]
            },
            "audio-settings": {
                "type": "object",
                "title": "Audio Settings",
                "description": "",
                "allOf": [
                    {
                        "type": "object",
                        "properties": {
                            "lv": {
                                "title": "Level",
                                "$ref": "#/$defs/animated-properties/multi-dimensional"
                            }
                        },
                        "required": [
                            "lv"
                        ]
                    }
                ]
            },
            "layer": {
                "type": "object",
                "title": "Layer",
                "description": "",
                "allOf": [
                    {
                        "$ref": "#/$defs/helpers/visual-object"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ddd": {
                                "title": "Threedimensional",
                                "description": "Whether the layer is threedimensional",
                                "$ref": "#/$defs/helpers/int-boolean",
                                "default": 0
                            },
                            "hd": {
                                "title": "Hidden",
                                "description": "Whether the layer is hidden",
                                "type": "boolean"
                            },
                            "ty": {
                                "title": "Type",
                                "description": "Layer Type",
                                "type": "integer",
                                "oneOf": [
                                    {
                                        "const": 0,
                                        "title": "Precomposition layer"
                                    },
                                    {
                                        "const": 1,
                                        "title": "Solid color layer"
                                    },
                                    {
                                        "const": 2,
                                        "title": "Image layer"
                                    },
                                    {
                                        "const": 3,
                                        "title": "Null layer"
                                    },
                                    {
                                        "const": 4,
                                        "title": "Shape layer"
                                    },
                                    {
                                        "const": 5,
                                        "title": "Text layer"
                                    },
                                    {
                                        "const": 6,
                                        "title": "Audio layer"
                                    },
                                    {
                                        "const": 7,
                                        "title": "Video placeholder"
                                    },
                                    {
                                        "const": 8,
                                        "title": "Image sequence"
                                    },
                                    {
                                        "const": 9,
                                        "title": "Video layer"
                                    },
                                    {
                                        "const": 10,
                                        "title": "Image placeholder"
                                    },
                                    {
                                        "const": 11,
                                        "title": "Guide layer"
                                    },
                                    {
                                        "const": 12,
                                        "title": "Adjustment layer"
                                    },
                                    {
                                        "const": 13,
                                        "title": "Camera"
                                    },
                                    {
                                        "const": 14,
                                        "title": "Light layer"
                                    },
                                    {
                                        "const": 15,
                                        "title": "Data layer"
                                    }
                                ]
                            },
                            "ind": {
                                "title": "Index",
                                "type": "integer",
                                "description": "Index that can be used for parenting and referenced in expressions"
                            },
                            "parent": {
                                "title": "Parent Index",
                                "description": "Must be the `ind` property of another layer",
                                "type": "integer"
                            },
                            "sr": {
                                "title": "Time Stretch",
                                "caniuse": "property-time-stretch",
                                "type": "number",
                                "default": 1
                            },
                            "ip": {
                                "title": "In Point",
                                "description": "Frame when the layer becomes visible",
                                "type": "number"
                            },
                            "op": {
                                "title": "Out Point",
                                "description": "Frame when the layer becomes invisible",
                                "type": "number"
                            },
                            "st": {
                                "title": "Start Time",
                                "type": "number",
                                "default": 0
                            }
                        },
                        "required": [
                            "ty",
                            "st",
                            "ip",
                            "op"
                        ]
                    }
                ]
            }
        },
        "shapes": {
            "gradient": {
                "type": "object",
                "title": "Gradient",
                "description": "",
                "allOf": [
                    {
                        "type": "object",
                        "properties": {
                            "s": {
                                "title": "Start Point",
                                "description": "Starting point for the gradient",
                                "$ref": "#/$defs/animated-properties/multi-dimensional"
                            },
                            "e": {
                                "title": "End Point",
                                "description": "End point for the gradient",
                                "$ref": "#/$defs/animated-properties/multi-dimensional"
                            },
                            "t": {
                                "title": "Gradient Type",
                                "description": "Type of the gradient",
                                "$ref": "#/$defs/constants/gradient-type",
                                "default": 1
                            },
                            "h": {
                                "title": "Highlight Length",
                                "description": "Highlight Length, as a percentage between `s` and `e`",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "a": {
                                "title": "Highlight Angle",
                                "description": "Highlight Angle, relative to the direction from `s` to `e`",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "g": {
                                "title": "Colors",
                                "description": "Gradient colors",
                                "$ref": "#/$defs/animated-properties/gradient-colors"
                            }
                        },
                        "required": [
                            "s",
                            "e",
                            "g"
                        ]
                    }
                ]
            },
            "repeater-transform": {
                "type": "object",
                "title": "Repeater Transform",
                "description": "Transform used by a repeater, the transform is applied to each subsequent repeated object.",
                "allOf": [
                    {
                        "$ref": "#/$defs/helpers/transform"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "so": {
                                "title": "Start Opacity",
                                "description": "Opacity of the first repeated object.",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "eo": {
                                "title": "End Opacity",
                                "description": "Opacity of the last repeated object.",
                                "$ref": "#/$defs/animated-properties/value"
                            }
                        },
                        "required": []
                    }
                ]
            },
            "shape-element": {
                "type": "object",
                "title": "Shape Element",
                "description": "Base class for all elements of ShapeLayer and Group",
                "allOf": [
                    {
                        "$ref": "#/$defs/helpers/visual-object"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "hd": {
                                "title": "Hidden",
                                "description": "Whether the shape is hidden",
                                "type": "boolean"
                            },
                            "ty": {
                                "title": "Shape Type",
                                "type": "string",
                                "oneOf": [
                                    {
                                        "const": "rc",
                                        "title": "Rectangle"
                                    },
                                    {
                                        "const": "el",
                                        "title": "Ellipse"
                                    },
                                    {
                                        "const": "sr",
                                        "title": "Polygon / Star"
                                    },
                                    {
                                        "const": "sh",
                                        "title": "Path"
                                    },
                                    {
                                        "const": "fl",
                                        "title": "Fill"
                                    },
                                    {
                                        "const": "st",
                                        "title": "Stroke"
                                    },
                                    {
                                        "const": "gf",
                                        "title": "Gradient fill"
                                    },
                                    {
                                        "const": "gs",
                                        "title": "Gradient stroke"
                                    },
                                    {
                                        "const": "no",
                                        "title": "No Style"
                                    },
                                    {
                                        "const": "gr",
                                        "title": "Group"
                                    },
                                    {
                                        "const": "tr",
                                        "title": "Transform"
                                    },
                                    {
                                        "const": "rd",
                                        "title": "Rounded corners"
                                    },
                                    {
                                        "const": "pb",
                                        "title": "Pucker / bloat"
                                    },
                                    {
                                        "const": "mm",
                                        "title": "Merge"
                                    },
                                    {
                                        "const": "tw",
                                        "title": "Twist"
                                    },
                                    {
                                        "const": "op",
                                        "title": "Offset path"
                                    },
                                    {
                                        "const": "zz",
                                        "title": "Zig zag"
                                    },
                                    {
                                        "const": "rp",
                                        "title": "Repeater"
                                    },
                                    {
                                        "const": "tm",
                                        "title": "Trim"
                                    }
                                ]
                            },
                            "bm": {
                                "title": "Blend Mode",
                                "$ref": "#/$defs/constants/blend-mode"
                            },
                            "ix": {
                                "title": "Property index",
                                "description": "Index used in expressions",
                                "type": "integer"
                            },
                            "cl": {
                                "title": "CSS Class",
                                "description": "CSS class used by the SVG renderer",
                                "type": "string"
                            },
                            "ln": {
                                "title": "Layer XML ID",
                                "description": "`id` attribute used by the SVG renderer",
                                "type": "string"
                            }
                        },
                        "required": [
                            "ty"
                        ]
                    }
                ]
            },
            "shape": {
                "type": "object",
                "title": "Shape",
                "description": "Drawable shape",
                "allOf": [
                    {
                        "$ref": "#/$defs/shapes/shape-element"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "d": {
                                "title": "Direction",
                                "description": "Direction the shape is drawn as, mostly relevant when using trim path",
                                "$ref": "#/$defs/constants/shape-direction"
                            }
                        }
                    }
                ]
            },
            "repeater": {
                "type": "object",
                "title": "Repeater",
                "description": "Duplicates previous shapes in a group",
                "caniuse": "shape-repeater",
                "allOf": [
                    {
                        "$ref": "#/$defs/shapes/modifier"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Shape Type",
                                "type": "string",
                                "const": "rp"
                            },
                            "c": {
                                "title": "Copies",
                                "description": "Number of copies",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "o": {
                                "title": "Offset",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "m": {
                                "title": "Composite",
                                "description": "Stacking order",
                                "$ref": "#/$defs/constants/composite",
                                "default": 1
                            },
                            "tr": {
                                "title": "Transform",
                                "description": "Transform applied to each copy",
                                "$ref": "#/$defs/shapes/repeater-transform"
                            }
                        },
                        "required": [
                            "ty",
                            "c",
                            "tr"
                        ]
                    }
                ]
            },
            "zig-zag": {
                "type": "object",
                "title": "Zig Zag",
                "description": "Changes the edges of affected shapes into a series of peaks and valleys of uniform size",
                "allOf": [
                    {
                        "$ref": "#/$defs/shapes/shape-element"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Shape Type",
                                "type": "string",
                                "const": "zz"
                            },
                            "r": {
                                "title": "Frequency",
                                "description": "Number of ridges per segment",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "s": {
                                "title": "Amplitude",
                                "description": "Distance between peaks and troughs",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "pt": {
                                "title": "Point Type",
                                "description": "Point type (1 = corner, 2 = smooth)",
                                "$ref": "#/$defs/animated-properties/value"
                            }
                        },
                        "required": [
                            "ty"
                        ]
                    }
                ]
            },
            "transform": {
                "type": "object",
                "title": "Transform Shape",
                "description": "Group transform",
                "allOf": [
                    {
                        "$ref": "#/$defs/shapes/shape-element"
                    },
                    {
                        "$ref": "#/$defs/helpers/transform"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Shape Type",
                                "type": "string",
                                "const": "tr"
                            }
                        },
                        "required": [
                            "ty"
                        ]
                    }
                ]
            },
            "path": {
                "type": "object",
                "title": "Path",
                "description": "Animatable Bezier curve",
                "caniuse": "shape-path",
                "allOf": [
                    {
                        "$ref": "#/$defs/shapes/shape"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Shape Type",
                                "type": "string",
                                "const": "sh"
                            },
                            "ks": {
                                "title": "Shape",
                                "description": "Bezier path",
                                "$ref": "#/$defs/animated-properties/shape-property"
                            }
                        },
                        "required": [
                            "ty",
                            "ks"
                        ]
                    }
                ]
            },
            "trim": {
                "type": "object",
                "title": "Trim",
                "description": "Trims shapes into a segment",
                "caniuse": "shape-trim-path",
                "allOf": [
                    {
                        "$ref": "#/$defs/shapes/modifier"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Shape Type",
                                "type": "string",
                                "const": "tm"
                            },
                            "s": {
                                "title": "Start",
                                "description": "Segment start",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "e": {
                                "title": "End",
                                "description": "Segment end",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "o": {
                                "title": "Offset",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "m": {
                                "title": "Multiple",
                                "description": "How to treat multiple copies",
                                "$ref": "#/$defs/constants/trim-multiple-shapes"
                            }
                        },
                        "required": [
                            "ty",
                            "o",
                            "s",
                            "e"
                        ]
                    }
                ]
            },
            "merge": {
                "type": "object",
                "title": "Merge",
                "caniuse": "shape-merge-path",
                "description": "Boolean operator on shapes",
                "allOf": [
                    {
                        "$ref": "#/$defs/shapes/shape-element"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Shape Type",
                                "type": "string",
                                "const": "mm"
                            },
                            "mm": {
                                "title": "Merge Mode",
                                "$ref": "#/$defs/constants/merge-mode",
                                "default": 1
                            }
                        },
                        "required": [
                            "ty"
                        ]
                    }
                ]
            },
            "fill": {
                "type": "object",
                "title": "Fill",
                "description": "Solid fill color",
                "caniuse": "shape-fill",
                "allOf": [
                    {
                        "$ref": "#/$defs/shapes/shape-element"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Shape Type",
                                "type": "string",
                                "const": "fl"
                            },
                            "o": {
                                "title": "Opacity",
                                "description": "Opacity, 100 means fully opaque",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "c": {
                                "title": "Color",
                                "$ref": "#/$defs/animated-properties/color-value"
                            },
                            "r": {
                                "title": "Fill Rule",
                                "$ref": "#/$defs/constants/fill-rule"
                            }
                        },
                        "required": [
                            "ty",
                            "c",
                            "o"
                        ]
                    }
                ]
            },
            "no-style": {
                "type": "object",
                "title": "No Style",
                "description": "Represents a style for shapes without fill or stroke",
                "allOf": [
                    {
                        "$ref": "#/$defs/shapes/shape-element"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Shape Type",
                                "type": "string",
                                "const": "no"
                            }
                        },
                        "required": [
                            "ty"
                        ]
                    }
                ]
            },
            "pucker-bloat": {
                "type": "object",
                "title": "Pucker Bloat",
                "description": "Interpolates the shape with its center point and bezier tangents with the opposite direction",
                "caniuse": "shape-pucker-and-bloat",
                "allOf": [
                    {
                        "$ref": "#/$defs/shapes/shape-element"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Shape Type",
                                "type": "string",
                                "const": "pb"
                            },
                            "a": {
                                "title": "Amount",
                                "description": "Amount as a percentage",
                                "$ref": "#/$defs/animated-properties/value"
                            }
                        },
                        "required": [
                            "ty"
                        ]
                    }
                ]
            },
            "gradient-stroke": {
                "type": "object",
                "title": "Gradient Stroke",
                "description": "Gradient stroke",
                "caniuse": "shape-stroke-gradient",
                "allOf": [
                    {
                        "$ref": "#/$defs/shapes/shape-element"
                    },
                    {
                        "$ref": "#/$defs/shapes/base-stroke"
                    },
                    {
                        "$ref": "#/$defs/shapes/gradient"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Shape Type",
                                "type": "string",
                                "const": "gs"
                            }
                        },
                        "required": [
                            "ty"
                        ]
                    }
                ]
            },
            "stroke-dash": {
                "type": "object",
                "title": "Stroke Dash",
                "description": "An item used to described the dashe pattern in a stroked path",
                "allOf": [
                    {
                        "$ref": "#/$defs/helpers/visual-object"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "n": {
                                "title": "Dash Type",
                                "$ref": "#/$defs/constants/stroke-dash-type",
                                "default": "d"
                            },
                            "v": {
                                "title": "Length",
                                "description": "Length of the dash",
                                "$ref": "#/$defs/animated-properties/value"
                            }
                        },
                        "required": []
                    }
                ]
            },
            "ellipse": {
                "type": "object",
                "title": "Ellipse",
                "description": "Ellipse shape",
                "caniuse": "shape-ellipse",
                "allOf": [
                    {
                        "$ref": "#/$defs/shapes/shape"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Shape Type",
                                "type": "string",
                                "const": "el"
                            },
                            "p": {
                                "title": "Position",
                                "$ref": "#/$defs/animated-properties/position"
                            },
                            "s": {
                                "title": "Size",
                                "$ref": "#/$defs/animated-properties/multi-dimensional"
                            }
                        },
                        "required": [
                            "ty",
                            "s",
                            "p"
                        ]
                    }
                ]
            },
            "group": {
                "type": "object",
                "title": "Group",
                "description": "Shape Element that can contain other shapes",
                "allOf": [
                    {
                        "$ref": "#/$defs/shapes/shape-element"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Shape Type",
                                "type": "string",
                                "const": "gr"
                            },
                            "np": {
                                "title": "Number Of Properties",
                                "type": "number"
                            },
                            "it": {
                                "title": "Shapes",
                                "$ref": "#/$defs/shapes/shape-list"
                            },
                            "cix": {
                                "title": "Property index",
                                "description": "Index used in expressions",
                                "type": "integer"
                            }
                        },
                        "required": [
                            "ty"
                        ]
                    }
                ]
            },
            "polystar": {
                "type": "object",
                "title": "PolyStar",
                "description": "Star or regular polygon",
                "caniuse": "shape-polystar",
                "allOf": [
                    {
                        "$ref": "#/$defs/shapes/shape"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Shape Type",
                                "type": "string",
                                "const": "sr"
                            },
                            "p": {
                                "title": "Position",
                                "$ref": "#/$defs/animated-properties/position"
                            },
                            "or": {
                                "title": "Outer Radius",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "os": {
                                "title": "Outer Roundness",
                                "description": "Outer Roundness as a percentage",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "r": {
                                "title": "Rotation",
                                "description": "Rotation, clockwise in degrees",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "pt": {
                                "title": "Points",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "sy": {
                                "title": "Star Type",
                                "description": "Star type, `1` for Star, `2` for Polygon",
                                "$ref": "#/$defs/constants/star-type",
                                "default": 1
                            }
                        },
                        "required": [
                            "ty",
                            "or",
                            "os",
                            "pt",
                            "p",
                            "r"
                        ]
                    },
                    {
                        "if": {
                            "properties": {
                                "sy": {
                                    "const": 1
                                }
                            }
                        },
                        "then": {
                            "properties": {
                                "ir": {
                                    "title": "Inner Radius",
                                    "$ref": "#/$defs/animated-properties/value"
                                },
                                "is": {
                                    "title": "Inner Roundness",
                                    "description": "Inner Roundness as a percentage",
                                    "$ref": "#/$defs/animated-properties/value"
                                }
                            },
                            "required": [
                                "ir",
                                "is"
                            ]
                        }
                    }
                ]
            },
            "rounded-corners": {
                "type": "object",
                "title": "Rounded Corners",
                "description": "Rounds corners of other shapes",
                "allOf": [
                    {
                        "$ref": "#/$defs/shapes/modifier"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Shape Type",
                                "type": "string",
                                "const": "rd"
                            },
                            "r": {
                                "title": "Radius",
                                "$ref": "#/$defs/animated-properties/value"
                            }
                        },
                        "required": [
                            "ty",
                            "r"
                        ]
                    }
                ]
            },
            "stroke": {
                "type": "object",
                "title": "Stroke",
                "description": "Solid stroke",
                "caniuse": "shape-stroke",
                "allOf": [
                    {
                        "$ref": "#/$defs/shapes/shape-element"
                    },
                    {
                        "$ref": "#/$defs/shapes/base-stroke"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Shape Type",
                                "type": "string",
                                "const": "st"
                            },
                            "c": {
                                "title": "Color",
                                "description": "Stroke color",
                                "$ref": "#/$defs/animated-properties/color-value"
                            }
                        },
                        "required": [
                            "ty",
                            "c"
                        ]
                    }
                ]
            },
            "base-stroke": {
                "type": "object",
                "title": "Base Stroke",
                "description": "",
                "allOf": [
                    {
                        "type": "object",
                        "properties": {
                            "lc": {
                                "title": "Line Cap",
                                "$ref": "#/$defs/constants/line-cap",
                                "default": 2
                            },
                            "lj": {
                                "title": "Line Join",
                                "$ref": "#/$defs/constants/line-join",
                                "default": 2
                            },
                            "ml": {
                                "title": "Miter Limit",
                                "type": "number",
                                "default": 0
                            },
                            "ml2": {
                                "title": "Miter Limit",
                                "description": "Animatable alternative to ml",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "o": {
                                "title": "Opacity",
                                "description": "Opacity, 100 means fully opaque",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "w": {
                                "title": "Width",
                                "description": "Stroke width",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "d": {
                                "title": "Dashes",
                                "description": "Dashed line definition",
                                "type": "array",
                                "items": {
                                    "$ref": "#/$defs/shapes/stroke-dash"
                                }
                            }
                        },
                        "required": [
                            "o",
                            "w"
                        ]
                    }
                ]
            },
            "offset-path": {
                "type": "object",
                "title": "Offset Path",
                "caniuse": "shape-offset-path",
                "description": "Interpolates the shape with its center point and bezier tangents with the opposite direction",
                "allOf": [
                    {
                        "$ref": "#/$defs/shapes/shape-element"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Shape Type",
                                "type": "string",
                                "const": "op"
                            },
                            "a": {
                                "title": "Amount",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "lj": {
                                "title": "Line Join",
                                "$ref": "#/$defs/constants/line-join",
                                "default": 2
                            },
                            "ml": {
                                "title": "Miter Limit",
                                "$ref": "#/$defs/animated-properties/value"
                            }
                        },
                        "required": [
                            "ty"
                        ]
                    }
                ]
            },
            "rectangle": {
                "type": "object",
                "title": "Rectangle",
                "description": "A simple rectangle shape",
                "caniuse": "shape-rectangle",
                "allOf": [
                    {
                        "$ref": "#/$defs/shapes/shape"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Shape Type",
                                "type": "string",
                                "const": "rc"
                            },
                            "p": {
                                "title": "Position",
                                "description": "Center of the rectangle",
                                "$ref": "#/$defs/animated-properties/position"
                            },
                            "s": {
                                "title": "Size",
                                "$ref": "#/$defs/animated-properties/multi-dimensional"
                            },
                            "r": {
                                "title": "Rounded",
                                "description": "Rounded corners radius",
                                "$ref": "#/$defs/animated-properties/value"
                            }
                        },
                        "required": [
                            "ty",
                            "s",
                            "p",
                            "r"
                        ]
                    }
                ]
            },
            "modifier": {
                "type": "object",
                "title": "Modifier",
                "description": "",
                "allOf": [
                    {
                        "$ref": "#/$defs/shapes/shape-element"
                    }
                ]
            },
            "gradient-fill": {
                "type": "object",
                "title": "Gradient Fill",
                "description": "Gradient fill",
                "caniuse": "shape-fill-gradient",
                "allOf": [
                    {
                        "$ref": "#/$defs/shapes/shape-element"
                    },
                    {
                        "$ref": "#/$defs/shapes/gradient"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Shape Type",
                                "type": "string",
                                "const": "gf"
                            },
                            "o": {
                                "title": "Opacity",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "r": {
                                "title": "Fill Rule",
                                "$ref": "#/$defs/constants/fill-rule"
                            }
                        },
                        "required": [
                            "ty",
                            "o"
                        ]
                    }
                ]
            },
            "twist": {
                "type": "object",
                "title": "Twist",
                "description": "",
                "allOf": [
                    {
                        "$ref": "#/$defs/shapes/shape-element"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Shape Type",
                                "type": "string",
                                "const": "tw"
                            },
                            "a": {
                                "title": "Angle",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "c": {
                                "title": "Center",
                                "$ref": "#/$defs/animated-properties/multi-dimensional"
                            }
                        },
                        "required": [
                            "ty"
                        ]
                    }
                ]
            },
            "shape-list": {
                "title": "Shape List",
                "description": "List of valid shapes",
                "type": "array",
                "items": {
                    "oneOf": [
                        {
                            "$ref": "#/$defs/shapes/ellipse"
                        },
                        {
                            "$ref": "#/$defs/shapes/fill"
                        },
                        {
                            "$ref": "#/$defs/shapes/gradient-fill"
                        },
                        {
                            "$ref": "#/$defs/shapes/gradient-stroke"
                        },
                        {
                            "$ref": "#/$defs/shapes/group"
                        },
                        {
                            "$ref": "#/$defs/shapes/path"
                        },
                        {
                            "$ref": "#/$defs/shapes/polystar"
                        },
                        {
                            "$ref": "#/$defs/shapes/pucker-bloat"
                        },
                        {
                            "$ref": "#/$defs/shapes/rectangle"
                        },
                        {
                            "$ref": "#/$defs/shapes/repeater"
                        },
                        {
                            "$ref": "#/$defs/shapes/rounded-corners"
                        },
                        {
                            "$ref": "#/$defs/shapes/stroke"
                        },
                        {
                            "$ref": "#/$defs/shapes/transform"
                        },
                        {
                            "$ref": "#/$defs/shapes/trim"
                        },
                        {
                            "$ref": "#/$defs/shapes/twist"
                        },
                        {
                            "$ref": "#/$defs/shapes/merge"
                        },
                        {
                            "$ref": "#/$defs/shapes/offset-path"
                        },
                        {
                            "$ref": "#/$defs/shapes/zig-zag"
                        },
                        {
                            "$ref": "#/$defs/shapes/no-style"
                        }
                    ]
                }
            }
        },
        "styles": {
            "gradient-overlay-style": {
                "type": "object",
                "title": "Gradient Overlay",
                "caniuse": "style-gradient-overlay",
                "allOf": [
                    {
                        "$ref": "#/$defs/styles/layer-style"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Type",
                                "description": "Layer Type",
                                "type": "integer",
                                "const": 8
                            },
                            "bm": {
                                "title": "Blend Mode",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "o": {
                                "title": "Opacity",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "gf": {
                                "title": "Gradient",
                                "$ref": "#/$defs/animated-properties/gradient-colors"
                            },
                            "gs": {
                                "title": "Smoothness",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "a": {
                                "title": "Angle",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "gt": {
                                "title": "Gradient Type",
                                "$ref": "#/$defs/constants/gradient-type"
                            },
                            "re": {
                                "title": "Reverse",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "al": {
                                "title": "Align",
                                "description": "Align with layer",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "s": {
                                "title": "Scale",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "of": {
                                "title": "Offset",
                                "$ref": "#/$defs/animated-properties/value"
                            }
                        },
                        "required": [
                            "ty"
                        ]
                    }
                ]
            },
            "inner-glow-style": {
                "type": "object",
                "title": "Inner Glow",
                "caniuse": "style-inner-glow",
                "allOf": [
                    {
                        "$ref": "#/$defs/styles/layer-style"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Type",
                                "description": "Layer Type",
                                "type": "integer",
                                "const": 4
                            },
                            "c": {
                                "title": "Color",
                                "$ref": "#/$defs/animated-properties/color-value"
                            },
                            "o": {
                                "title": "Opacity",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "r": {
                                "title": "Range",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "sr": {
                                "title": "Source",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "ch": {
                                "title": "Choke Spread",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "bm": {
                                "title": "Blend Mode",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "no": {
                                "title": "Noise",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "j": {
                                "title": "Jitter",
                                "$ref": "#/$defs/animated-properties/value"
                            }
                        },
                        "required": [
                            "ty"
                        ]
                    }
                ]
            },
            "outer-glow-style": {
                "type": "object",
                "title": "Outer Glow",
                "caniuse": "style-outer-glow",
                "allOf": [
                    {
                        "$ref": "#/$defs/styles/layer-style"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Type",
                                "description": "Layer Type",
                                "type": "integer",
                                "const": 3
                            },
                            "c": {
                                "title": "Color",
                                "$ref": "#/$defs/animated-properties/color-value"
                            },
                            "o": {
                                "title": "Opacity",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "r": {
                                "title": "Range",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "ch": {
                                "title": "Choke Spread",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "bm": {
                                "title": "Blend Mode",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "no": {
                                "title": "Noise",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "j": {
                                "title": "Jitter",
                                "$ref": "#/$defs/animated-properties/value"
                            }
                        },
                        "required": [
                            "ty"
                        ]
                    }
                ]
            },
            "satin-style": {
                "type": "object",
                "title": "Satin",
                "caniuse": "style-satin",
                "allOf": [
                    {
                        "$ref": "#/$defs/styles/layer-style"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Type",
                                "description": "Layer Type",
                                "type": "integer",
                                "const": 6
                            },
                            "bm": {
                                "title": "Blend Mode",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "c": {
                                "title": "Color",
                                "$ref": "#/$defs/animated-properties/color-value"
                            },
                            "o": {
                                "title": "Opacity",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "a": {
                                "title": "Angle",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "d": {
                                "title": "Distance",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "s": {
                                "title": "Size",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "in": {
                                "title": "Invert",
                                "$ref": "#/$defs/animated-properties/value"
                            }
                        },
                        "required": [
                            "ty"
                        ]
                    }
                ]
            },
            "color-overlay-style": {
                "type": "object",
                "title": "Color Overlay",
                "caniuse": "style-color-overlay",
                "allOf": [
                    {
                        "$ref": "#/$defs/styles/layer-style"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Type",
                                "description": "Layer Type",
                                "type": "integer",
                                "const": 7
                            },
                            "bm": {
                                "title": "Blend Mode",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "c": {
                                "title": "Color",
                                "$ref": "#/$defs/animated-properties/color-value"
                            },
                            "so": {
                                "title": "Opacity",
                                "$ref": "#/$defs/animated-properties/value"
                            }
                        },
                        "required": [
                            "ty"
                        ]
                    }
                ]
            },
            "inner-shadow-style": {
                "type": "object",
                "title": "Inner Shadow",
                "caniuse": "style-inner-shadow",
                "allOf": [
                    {
                        "$ref": "#/$defs/styles/layer-style"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Type",
                                "description": "Layer Type",
                                "type": "integer",
                                "const": 2
                            },
                            "c": {
                                "title": "Color",
                                "$ref": "#/$defs/animated-properties/color-value"
                            },
                            "o": {
                                "title": "Opacity",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "a": {
                                "title": "Angle",
                                "description": "Local light angle",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "s": {
                                "title": "Size",
                                "description": "Blur size",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "d": {
                                "title": "Distance",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "ch": {
                                "title": "Choke Spread",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "bm": {
                                "title": "Blend Mode",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "no": {
                                "title": "Noise",
                                "$ref": "#/$defs/animated-properties/value"
                            }
                        },
                        "required": [
                            "ty"
                        ]
                    }
                ]
            },
            "stroke-style": {
                "type": "object",
                "title": "Layer Stroke",
                "caniuse": "style-stroke",
                "description": "Stroke / frame",
                "allOf": [
                    {
                        "$ref": "#/$defs/styles/layer-style"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Type",
                                "description": "Layer Type",
                                "type": "integer",
                                "const": 0
                            },
                            "s": {
                                "title": "Size",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "c": {
                                "title": "Color",
                                "$ref": "#/$defs/animated-properties/color-value"
                            }
                        },
                        "required": [
                            "ty"
                        ]
                    }
                ]
            },
            "drop-shadow-style": {
                "type": "object",
                "title": "Drop Shadow",
                "caniuse": "style-drop-shadow",
                "allOf": [
                    {
                        "$ref": "#/$defs/styles/layer-style"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Type",
                                "description": "Layer Type",
                                "type": "integer",
                                "const": 1
                            },
                            "c": {
                                "title": "Color",
                                "$ref": "#/$defs/animated-properties/color-value"
                            },
                            "o": {
                                "title": "Opacity",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "a": {
                                "title": "Angle",
                                "description": "Local light angle",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "s": {
                                "title": "Size",
                                "description": "Blur size",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "d": {
                                "title": "Distance",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "ch": {
                                "title": "Choke Spread",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "bm": {
                                "title": "Blend Mode",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "no": {
                                "title": "Noise",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "lc": {
                                "title": "Layer Conceal",
                                "description": "Layer knowck out drop shadow",
                                "$ref": "#/$defs/animated-properties/value"
                            }
                        },
                        "required": [
                            "ty"
                        ]
                    }
                ]
            },
            "layer-style": {
                "type": "object",
                "title": "Layer Style",
                "description": "Style applied to a layer",
                "allOf": [
                    {
                        "$ref": "#/$defs/helpers/visual-object"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Type",
                                "description": "Style Type",
                                "type": "integer"
                            }
                        },
                        "required": [
                            "ty"
                        ]
                    }
                ]
            },
            "bevel-emboss-style": {
                "type": "object",
                "title": "Bevel Emboss",
                "caniuse": "style-bevel-and-emboss",
                "allOf": [
                    {
                        "$ref": "#/$defs/styles/layer-style"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "ty": {
                                "title": "Type",
                                "description": "Layer Type",
                                "type": "integer",
                                "const": 5
                            },
                            "bs": {
                                "title": "Bevel Style",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "bt": {
                                "title": "Technique",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "sr": {
                                "title": "Strength",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "s": {
                                "title": "Size",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "sf": {
                                "title": "Soften",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "ga": {
                                "title": "Global Angle",
                                "description": "Use global light",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "a": {
                                "title": "Angle",
                                "description": "Local lighting angle",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "ll": {
                                "title": "Altitude",
                                "description": "Local lighting altitude",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "hm": {
                                "title": "Highlight Mode",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "hc": {
                                "title": "Highlight Color",
                                "$ref": "#/$defs/animated-properties/color-value"
                            },
                            "ho": {
                                "title": "Highlight Opacity",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "sm": {
                                "title": "Shadow Mode",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "sc": {
                                "title": "Shadow Color",
                                "$ref": "#/$defs/animated-properties/color-value"
                            },
                            "so": {
                                "title": "Shadow Opacity",
                                "$ref": "#/$defs/animated-properties/value"
                            }
                        },
                        "required": [
                            "ty"
                        ]
                    }
                ]
            }
        },
        "text": {
            "font-list": {
                "type": "object",
                "title": "Font List",
                "description": "List of fonts",
                "allOf": [
                    {
                        "type": "object",
                        "properties": {
                            "list": {
                                "title": "List",
                                "type": "array",
                                "items": {
                                    "$ref": "#/$defs/text/font"
                                }
                            }
                        },
                        "required": []
                    }
                ]
            },
            "text-style": {
                "type": "object",
                "title": "Text Style",
                "description": "",
                "allOf": [
                    {
                        "$ref": "#/$defs/helpers/transform"
                    },
                    {
                        "type": "object",
                        "properties": {
                            "sw": {
                                "title": "Stroke Width",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "sc": {
                                "title": "Stroke Color",
                                "$ref": "#/$defs/animated-properties/color-value"
                            },
                            "sh": {
                                "title": "Stroke Hue",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "ss": {
                                "title": "Stroke Saturation",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "sb": {
                                "title": "Stroke Brightness",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "so": {
                                "title": "Stroke Opacity",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "fc": {
                                "title": "Fill Color",
                                "$ref": "#/$defs/animated-properties/color-value"
                            },
                            "fh": {
                                "title": "Fill Hue",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "fs": {
                                "title": "Fill Saturation",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "fb": {
                                "title": "Fill Brightness",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "fo": {
                                "title": "Fill Opacity",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "t": {
                                "title": "Letter Spacing",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "bl": {
                                "title": "Blur",
                                "caniuse": "text-animators-blur",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "ls": {
                                "title": "Line Spacing",
                                "$ref": "#/$defs/animated-properties/value"
                            }
                        },
                        "required": []
                    }
                ]
            },
            "text-alignment-options": {
                "type": "object",
                "title": "Text Alignment Options",
                "description": "",
                "allOf": [
                    {
                        "type": "object",
                        "properties": {
                            "a": {
                                "title": "Alignment",
                                "description": "Group alignment",
                                "caniuse": "animators-grouping-alignment",
                                "$ref": "#/$defs/animated-properties/multi-dimensional"
                            },
                            "g": {
                                "title": "Grouping",
                                "description": "Anchor point grouping",
                                "caniuse": "animators-anchor-point-grouping",
                                "$ref": "#/$defs/constants/text-grouping"
                            }
                        },
                        "required": []
                    }
                ]
            },
            "text-data": {
                "type": "object",
                "title": "Text Data",
                "description": "Contains all the text data and animation",
                "allOf": [
                    {
                        "type": "object",
                        "properties": {
                            "a": {
                                "title": "Ranges",
                                "caniuse": "text-animators",
                                "type": "array",
                                "items": {
                                    "$ref": "#/$defs/text/text-range"
                                }
                            },
                            "d": {
                                "title": "Document",
                                "$ref": "#/$defs/text/animated-text-document"
                            },
                            "m": {
                                "title": "Alignment",
                                "$ref": "#/$defs/text/text-alignment-options"
                            },
                            "p": {
                                "title": "Follow Path",
                                "$ref": "#/$defs/text/text-follow-path"
                            }
                        },
                        "required": [
                            "a",
                            "d",
                            "m",
                            "p"
                        ]
                    }
                ]
            },
            "character-precomp": {
                "type": "object",
                "title": "Character Precomp",
                "description": "Defines a character as a precomp layer",
                "properties": {
                    "refId": {
                        "title": "Reference Id",
                        "description": "ID of the precomp as specified in the assets",
                        "type": "string"
                    },
                    "ks": {
                        "title": "Transform",
                        "description": "Layer transform",
                        "$ref": "#/$defs/helpers/transform"
                    },
                    "ip": {
                        "title": "In Point",
                        "description": "Frame when the layer becomes visible",
                        "type": "number",
                        "default": 0
                    },
                    "op": {
                        "title": "Out Point",
                        "description": "Frame when the layer becomes invisible",
                        "type": "number",
                        "default": 99999
                    },
                    "sr": {
                        "title": "Time Stretch",
                        "type": "number",
                        "default": 1
                    },
                    "st": {
                        "title": "Start Time",
                        "type": "number",
                        "default": 0
                    }
                },
                "required": [
                    "refId"
                ]
            },
            "animated-text-document": {
                "type": "object",
                "title": "Animated Text Document",
                "description": "Animated property representing the text contents",
                "properties": {
                    "k": {
                        "title": "Keyframes",
                        "type": "array",
                        "items": {
                            "$ref": "#/$defs/text/text-document-keyframe"
                        }
                    },
                    "x": {
                        "title": "Expression",
                        "type": "string"
                    }
                },
                "required": [
                    "k"
                ]
            },
            "character-data": {
                "type": "object",
                "title": "Character Data",
                "description": "Defines character shapes",
                "properties": {
                    "ch": {
                        "title": "Character",
                        "type": "string",
                        "default": ""
                    },
                    "fFamily": {
                        "title": "Font Family",
                        "type": "string",
                        "default": ""
                    },
                    "size": {
                        "title": "Font Size",
                        "type": "number",
                        "default": 0
                    },
                    "style": {
                        "title": "Font Style",
                        "type": "string",
                        "default": ""
                    },
                    "w": {
                        "title": "Width",
                        "type": "number",
                        "default": 0
                    },
                    "data": {
                        "title": "Data",
                        "oneOf": [
                            {
                                "$ref": "#/$defs/text/character-shapes"
                            },
                            {
                                "$ref": "#/$defs/text/character-precomp"
                            }
                        ]
                    }
                },
                "required": [
                    "data",
                    "ch",
                    "fFamily",
                    "size",
                    "style",
                    "w"
                ]
            },
            "text-follow-path": {
                "type": "object",
                "title": "Text Follow Path",
                "caniuse": "text-path",
                "description": "Uses the path described by a layer mask to put the text on said path.",
                "allOf": [
                    {
                        "type": "object",
                        "properties": {
                            "m": {
                                "title": "Mask",
                                "type": "integer",
                                "description": "Index of the mask to use"
                            },
                            "f": {
                                "title": "First Margin",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "l": {
                                "title": "Last Margin",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "r": {
                                "title": "Reverse Path",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "a": {
                                "title": "Force Alignment",
                                "$ref": "#/$defs/animated-properties/value"
                            },
                            "p": {
                                "title": "Perpendicular To Path",
                                "$ref": "#/$defs/animated-properties/value"
                            }
                        },
                        "required": []
                    }
                ]
            },
            "font": {
                "type": "object",
                "title": "Font",
                "description": "Describes how a font with given settings should be loaded",
                "allOf": [
                    {
                        "type": "object",
                        "properties": {
                            "ascent": {
                                "title": "Ascent",
                                "type": "number",
                                "description": "Text will be moved down based on this value"
                            },
                            "fFamily": {
                                "title": "Font Family",
                                "type": "string",
                                "default": "sans"
                            },
                            "fName": {
                                "title": "Name",
                                "description": "Name used by text documents to reference this font, usually it's `fFamily` followed by `fStyle`",
                                "type": "string",
                                "default": "sans-Regular"
                            },
                            "fStyle": {
                                "title": "Font Style",
                                "examples": [
                                    "Regular",
                                    "Bold",
                                    "Bold Italic"
                                ],
                                "type": "string",
                                "default": "Regular"
                            },
                            "fPath": {
                                "title": "Path",
                                "type": "string"
                            },
                            "fWeight": {
                                "title": "Weight",
                                "type": "string"
                            },
                            "origin": {
                                "title": "Origin",
                                "$ref": "#/$defs/constants/font-path-origin"
                            },
                            "fClass": {
                                "type": "string",
                                "title": "CSS Class",
                                "description": "CSS Class applied to text objects using this font"
                            }
                        },
                        "required": [
                            "fFamily",
                            "fName",
                            "fStyle"
                        ]
                    }
                ]
            },
            "text-document": {
                "type": "object",
                "title": "Text Document",
                "description": "",
                "properties": {
                    "f": {
                        "title": "Font Family",
                        "type": "string",
                        "default": ""
                    },
                    "fc": {
                        "title": "Fill Color",
                        "$ref": "#/$defs/helpers/color",
                        "default": [
                            0,
                            0,
                            0
                        ]
                    },
                    "sc": {
                        "title": "Stroke Color",
                        "$ref": "#/$defs/helpers/color"
                    },
                    "sw": {
                        "title": "Stroke Width",
                        "type": "number",
                        "default": 0
                    },
                    "of": {
                        "title": "Stroke Over Fill",
                        "description": "Render stroke above the fill",
                        "type": "boolean"
                    },
                    "s": {
                        "title": "Font Size",
                        "type": "number",
                        "default": 10
                    },
                    "lh": {
                        "title": "Line Height",
                        "description": "Distance between lines on multiline or wrapped text",
                        "type": "number"
                    },
                    "sz": {
                        "title": "Wrap Size",
                        "description": "Size of the box containing the text",
                        "type": "array",
                        "minItems": 2,
                        "maxItems": 2,
                        "items": {
                            "type": "number"
                        }
                    },
                    "ps": {
                        "title": "Wrap Position",
                        "description": "Position of the box containing the text",
                        "type": "array",
                        "minItems": 2,
                        "maxItems": 2,
                        "items": {
                            "type": "number"
                        }
                    },
                    "t": {
                        "title": "Text",
                        "type": "string",
                        "description": "Text, note that newlines are encoded with \\r",
                        "default": ""
                    },
                    "j": {
                        "title": "Justify",
                        "$ref": "#/$defs/constants/text-justify",
                        "default": 0
                    },
                    "ca": {
                        "title": "Text Caps",
                        "$ref": "#/$defs/constants/text-caps"
                    },
                    "tr": {
                        "title": "Tracking",
                        "description": "Text Tracking",
                        "type": "number"
                    },
                    "ls": {
                        "title": "Baseline Shift",
                        "type": "number"
                    }
                },
                "required": [
                    "f",
                    "fc",
                    "s",
                    "t"
                ]
            },
            "text-range": {
                "type": "object",
                "title": "Text Range",
                "description": "Range of text with custom animations and style",
                "caniuse": "animators-range-selectors",
                "properties": {
                    "nm": {
                        "title": "Name",
                        "type": "string"
                    },
                    "s": {
                        "title": "Selector",
                        "$ref": "#/$defs/text/text-range-selector"
                    },
                    "a": {
                        "title": "Style",
                        "$ref": "#/$defs/text/text-style"
                    }
                }
            },
            "text-document-keyframe": {
                "type": "object",
                "title": "Text Document Keyframe",
                "description": "A keyframe containing a text document",
                "properties": {
                    "s": {
                        "title": "Start",
                        "$ref": "#/$defs/text/text-document"
                    },
                    "t": {
                        "title": "Time",
                        "type": "number",
                        "default": 0
                    }
                },
                "required": [
                    "s",
                    "t"
                ]
            },
            "character-shapes": {
                "type": "object",
                "title": "Character Shape",
                "description": "Defines a character as shapes",
                "properties": {
                    "shapes": {
                        "title": "Shapes",
                        "description": "Shapes forming the character",
                        "$ref": "#/$defs/shapes/shape-list"
                    }
                },
                "required": [
                    "shapes"
                ]
            },
            "text-range-selector": {
                "type": "object",
                "title": "Text Range Selector",
                "caniuse": "animators-range-selectors",
                "properties": {
                    "t": {
                        "title": "Expressible",
                        "$ref": "#/$defs/helpers/int-boolean"
                    },
                    "xe": {
                        "title": "Max Ease",
                        "$ref": "#/$defs/animated-properties/value"
                    },
                    "ne": {
                        "title": "Min Ease",
                        "$ref": "#/$defs/animated-properties/value"
                    },
                    "a": {
                        "title": "Max Amount",
                        "$ref": "#/$defs/animated-properties/value"
                    },
                    "b": {
                        "title": "Based On",
                        "$ref": "#/$defs/constants/text-based"
                    },
                    "rn": {
                        "title": "Randomize",
                        "$ref": "#/$defs/helpers/int-boolean"
                    },
                    "sh": {
                        "title": "Shape",
                        "$ref": "#/$defs/constants/text-shape"
                    },
                    "o": {
                        "title": "Offset",
                        "$ref": "#/$defs/animated-properties/value"
                    },
                    "r": {
                        "title": "Range Units",
                        "caniuse": "range-selectors-units",
                        "$ref": "#/$defs/constants/text-range-units"
                    },
                    "sm": {
                        "title": "Selector Smoothness",
                        "$ref": "#/$defs/animated-properties/value"
                    },
                    "s": {
                        "title": "Start",
                        "$ref": "#/$defs/animated-properties/value"
                    },
                    "e": {
                        "title": "End",
                        "$ref": "#/$defs/animated-properties/value"
                    }
                },
                "required": [
                    "t",
                    "a",
                    "b",
                    "sh"
                ]
            }
        }
    }
}

module.exports = schema;