const path = require('path')
const crypto = require('crypto');
const fs = require('fs');

var Validator = require('jsonschema').Validator;
var v = new Validator();
const schema = require("./lottieSchema");

MAX_SIZE = 1024 * 512

exports.ParsingLottie = (file) =>{
  let lottie_json
  if (file.size > MAX_SIZE){
    return null
  }
  try {
    lottie_json = JSON.parse(file.buffer);
  } catch (e) {
    return null
  }
  
  var validationResult = v.validate(lottie_json, schema);
  if (validationResult.errors.length > 0){
    return null
  }
  return lottie_json
}

exports.SaveFile = (lottie_json) =>{
    let filename = crypto.randomUUID()+".json"
    let data = JSON.stringify(lottie_json);
    fs.writeFileSync(path.join(__dirname, 'save_data', filename), data);

    return filename
}

exports.ReadFile = (filename) =>{
  try {
    const data = fs.readFileSync(path.join(__dirname, 'save_data', filename), 'utf8');
    return data
    } catch (err) {
     return null
    }
}

exports.ChangeLottie = (lottie_json, newData) =>{
  let err = false
  let metadata =[
    { id: 0, name:"v", value: lottie_json.v },
    { id: 1, name:"meta", value: lottie_json.meta },
    { id: 2, name:"fr", value: lottie_json.fr },
    { id: 3, name:"ip", value: lottie_json.ip },
    { id: 4, name:"op", value: lottie_json.op },
    { id: 5, name:"w", value: lottie_json.w },
    { id: 6, name:"h", value: lottie_json.h },
    { id: 7, name:"nm", value: lottie_json.nm },
    { id: 8, name:"ddd", value: lottie_json.ddd },
  ]

  metadata.forEach((data) => {
    newData.forEach((ch) => {
      if(ch.id === data.id){
        if( typeof(data.value) === typeof({})){
          try{
            moreData = JSON.parse(ch.value)
          } catch {
            err = true
            return 
          }
          for (const [key, value] of Object.entries(moreData)) {
            lottie_json[ch.name][key] = value
          }
        } else{
          lottie_json[ch.name] = ch.value
        }
      }
    })
  })
  if (err){
    return null
  }
  return lottie_json
}

exports.ParseMetadata = (lottie_json) => {
  let metadata =[
    { id: 0, name:"v", description: "Версия", value: lottie_json.v },
    { id: 1, name:"meta", description: "Метаданные", value: lottie_json.meta },
    { id: 2, name:"fr", description: "Частота кадров", value: lottie_json.fr },
    { id: 3, name:"ip", description: "Начальный кадр", value: lottie_json.ip },
    { id: 4, name:"op", description: "Конечный кадр", value: lottie_json.op },
    { id: 5, name:"w", description: "Ширина", value: lottie_json.w },
    { id: 6, name:"h", description: "Высота", value: lottie_json.h },
    { id: 7, name:"nm", description: "Название", value: lottie_json.nm },
    { id: 8, name:"ddd", description: "2D/3D анимация", value: lottie_json.ddd },
  ]

  metadata.forEach((data) => {
    if (typeof(data.value) === typeof({})){
      try{
        data.value = JSON.stringify(data.value)
      } catch {
          return null
      }
    }
  })
  return metadata
}