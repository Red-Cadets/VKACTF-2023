
const express = require("express");

const router = express.Router();
const path = require('path')

const changeMetadata = require("./controllers/change")
const editorLottie = require("./controllers/editor")


const multer = require('multer');
const upload = multer()

router.use('/save_data', express.static(path.join(__dirname, "utils", 'save_data')))

router.get("/", (req, res) =>{
    res.render("index", {error:""});
})

router.post("/editor", upload.single('file'), editorLottie.EditorLottie)
router.post("/change", changeMetadata.ChangeMetadata)

module.exports = router;