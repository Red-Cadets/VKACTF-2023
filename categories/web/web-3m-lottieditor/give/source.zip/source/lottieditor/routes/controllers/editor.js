const utils = require("../utils/Lottie")

exports.EditorLottie = (req, res) => {
    var lottie_json, filename;

    lottie_json = utils.ParsingLottie(req.file)
    if (lottie_json == null){
      res.render("index", {error:"Ошибка в парсинге JSON Lottie"} );
      return
    }
    
    filename = utils.SaveFile(lottie_json)
    metadata = utils.ParseMetadata(lottie_json)

    res.render("editor", {filename:filename, metadata:metadata, error:""})
}
