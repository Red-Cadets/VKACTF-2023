from flask import Flask

import json

app = Flask(__name__)

config = open("config.json")
config_data = config.read()
config_json = json.loads(config_data)

app.config.update(config_json["application"])

#######################################################################################

import views