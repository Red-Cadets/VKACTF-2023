from flask import render_template, send_file

from app import app

from uuid import uuid4

import subprocess

@app.route("/")
def index():
    return render_template('index.html', title="Home")

@app.route("/html")
def cert_html():
    return render_template("certificate.html")

@app.route("/pdf")
def cert_pdf():
    templated = render_template("certificate.html")
    tmpName = "cert-"+str(uuid4())
    file = open("tmp/"+tmpName+".html", "w")
    file.write(templated)
    file.close()
    subprocess.run(["prince", f"tmp/{tmpName}.html", "-o", f"tmp/{tmpName}.pdf"])
    pdf_file = open("tmp/"+tmpName+".pdf", "rb").read()
    return send_file("tmp/"+tmpName+".pdf")